import './styles.css';
import * as api from './api.js';

const root=document.getElementById('deletePage');
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

function render(message=''){
  root.innerHTML=`<section class="panel legal-page"><p class="eyebrow">PAW &amp; HAND</p><h1>Delete your account</h1><p>This external page lets a Paw &amp; Hand user verify their account and permanently delete the account and associated app data.</p>${message?`<div class="notice">${esc(message)}</div>`:''}${api.cloudConfigured?`<form id="deleteForm"><label>Email<input id="email" type="email" autocomplete="email" required></label><label>Password<input id="password" type="password" autocomplete="current-password" minlength="8" required></label><label>Type DELETE to confirm<input id="confirm" autocomplete="off" required placeholder="DELETE"></label><button class="danger wide" id="deleteBtn">Verify and permanently delete</button></form>`:'<div class="notice">Account deletion is not configured on this deployment.</div>'}<p class="small">Deletion is permanent. It removes profile media first, then deletes the authentication account and account-linked application records. If the sign-in credentials are unavailable, contact mopo39999@gmail.com for support-assisted identity verification.</p><p class="legal-links"><a href="./">Back to Paw &amp; Hand</a><a href="./privacy.html">Privacy</a></p></section>`;
  document.getElementById('deleteForm')?.addEventListener('submit',submitDelete);
}

async function submitDelete(e){
  e.preventDefault();
  if(document.getElementById('confirm').value.trim()!=='DELETE'){render('Type DELETE exactly to confirm.');return;}
  const btn=document.getElementById('deleteBtn');btn.disabled=true;btn.textContent='Deleting…';
  try{
    await api.signIn(document.getElementById('email').value.trim(),document.getElementById('password').value);
    await api.deleteAccount();
    root.innerHTML='<section class="panel legal-page"><p class="eyebrow">PAW &amp; HAND</p><h1>Account deleted</h1><div class="notice">Your Paw &amp; Hand account deletion completed.</div><p><a href="./">Return to Paw &amp; Hand</a></p></section>';
  }catch(err){
    render(err?.message||'Account deletion could not be completed.');
  }
}

render();
