import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import * as api from './api.js';

let navigationHandle=null;

export function nativePushSupported(){
  return Capacitor.isNativePlatform() && ['android','ios'].includes(Capacitor.getPlatform());
}


export async function initNativePushNavigation(){
  if(!nativePushSupported()||navigationHandle) return false;
  navigationHandle=await PushNotifications.addListener('pushNotificationActionPerformed',event=>{
    const data=event.notification?.data||{};
    try{sessionStorage.setItem('paw_push_open',JSON.stringify(data));}catch{}
    try{window.dispatchEvent(new CustomEvent('paw:push-open',{detail:data}));}catch{}
  });
  return true;
}

export async function enableNativePush(userId){
  if(!nativePushSupported()) throw new Error('Push notifications are available in the installed Android/iPhone app.');
  const platform=Capacitor.getPlatform();
  let permission=await PushNotifications.checkPermissions();
  if(permission.receive!=='granted') permission=await PushNotifications.requestPermissions();
  if(permission.receive!=='granted') throw new Error('Notification permission was not granted.');

  await PushNotifications.removeAllListeners();
  const registration=new Promise((resolve,reject)=>{
    const timeout=setTimeout(()=>reject(new Error('Push registration timed out.')),15000);
    PushNotifications.addListener('registration',async token=>{
      clearTimeout(timeout);
      try{await api.registerPushDevice(userId,token.value,platform);resolve({token:token.value,platform});}
      catch(error){reject(error);}
    });
    PushNotifications.addListener('registrationError',error=>{clearTimeout(timeout);reject(new Error(error?.error||'Push registration failed.'));});
  });
  await initNativePushNavigation();
  await PushNotifications.register();
  return registration;
}
