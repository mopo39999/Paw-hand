import './styles.css';
import * as api from './api.js';
const PUBLIC_SITE=(import.meta.env.VITE_PUBLIC_SITE_URL||'').replace(/\/$/,'');
const publicUrl=path=>PUBLIC_SITE?`${PUBLIC_SITE}/${path}`:`./${path}.html`;

const root=document.getElementById('app');
const activities=['Dog parks','Hiking','Camping','Road trips','Coffee walks','Homebody nights','Lake days','Live music'];
const demoProfiles=[
{id:'demo-maya',name:'Maya',age:39,gender:'Woman',showMe:'Men',lookingFor:'Long-term relationship',bio:'Weekend trail walks, good coffee, and a dog who believes every stranger is a future best friend.',kids:'I want kids someday',smoking:'Non-smoker',pace:'Active & outdoorsy',activities:['Hiking','Coffee walks','Road trips','Lake days'],weights:{people:4,dog:5,lifestyle:3},locationLabel:'Nearby',dog:{name:'Luna',breed:'Labrador mix',age:5,size:'Large',energy:'Medium',temperament:'Friendly',goodWith:'Most dogs'}},
{id:'demo-sarah',name:'Sarah',age:42,gender:'Woman',showMe:'Men',lookingFor:'Relationship, open to seeing where it goes',bio:'Quiet nights, lake weekends, and spontaneous drives with no destination.',kids:'No preference',smoking:'Non-smoker',pace:'Balanced',activities:['Camping','Road trips','Homebody nights','Lake days'],weights:{people:4,dog:5,lifestyle:3},locationLabel:'Nearby',dog:{name:'Winston',breed:'Golden Retriever',age:3,size:'Large',energy:'High',temperament:'Playful',goodWith:'Most dogs'}},
{id:'demo-nicole',name:'Nicole',age:37,gender:'Woman',showMe:'Men',lookingFor:'Long-term relationship',bio:'Dog mom, home cook, and professional finder of the best walking trails around town.',kids:'I have kids',smoking:'Non-smoker',pace:'Balanced',activities:['Dog parks','Hiking','Homebody nights','Coffee walks'],weights:{people:4,dog:5,lifestyle:3},locationLabel:'Nearby',dog:{name:'Milo',breed:'Mini Goldendoodle',age:4,size:'Medium',energy:'Medium',temperament:'Easygoing',goodWith:'Most dogs'}}
];

const defaultMe=()=>({name:'Alex',age:41,gender:'Man',showMe:'Women',lookingFor:'Long-term relationship',bio:'Dog person, road-trip fan, and believer that the best plans usually include four paws.',kids:'No preference',smoking:'Non-smoker',pace:'Balanced',activities:['Road trips','Hiking','Coffee walks'],weights:{people:4,dog:5,lifestyle:3},locationLabel:'',ageMin:30,ageMax:55,preferredDogSizes:['Small','Medium','Large','Extra large'],preferredDogEnergies:['Low','Medium','High'],avoidSmokers:false,requireSharedActivity:false,moderationStatus:'active',dog:{name:'Buddy',breed:'Goldendoodle',age:4,size:'Medium',energy:'Medium',temperament:'Friendly',goodWith:'Most dogs'}});

let state={session:null,me:null,profiles:[],matches:[],notifications:[],view:'discover',demo:false,demoChats:{},demoMatched:new Set(),chatCleanup:null,notificationCleanup:null,loading:false};
window.addEventListener('paw:push-open',e=>{if(state.me)openNotificationTarget(notificationFromPushData(e.detail||{})).catch(()=>{});});
const escapeHTML=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const toast=message=>{let t=document.querySelector('.toast');if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t);}t.textContent=message;requestAnimationFrame(()=>t.classList.add('show'));clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),1800);};
const setBusy=(btn,busy,label='Working…')=>{if(!btn)return;btn.disabled=busy;if(busy){btn.dataset.old=btn.textContent;btn.textContent=label;}else if(btn.dataset.old){btn.textContent=btn.dataset.old;delete btn.dataset.old;}};
const safe=async(fn,onError)=>{try{return await fn();}catch(err){console.error(err);toast(onError||err.message||'Something went wrong.');return null;}};
const blockedPhrases=['child porn','underage sex','rape fantasy','kill yourself','i will kill you',"i'm going to kill you",'send nudes','pay me for sex','escort services'];
const contentAllowed=text=>!blockedPhrases.some(term=>String(text||'').toLowerCase().includes(term));
const contentCheck=(...parts)=>{if(parts.every(contentAllowed))return true;toast('That text conflicts with Paw & Hand community rules.');return false;};

function shell(content,{nav=false}={}){
  const unread=state.notifications.filter(n=>!n.read_at).length;
  root.innerHTML=`<div class="app-shell"><header class="topbar"><button class="brand" id="brand">🐾 Paw <span>&amp;</span> Hand</button><div class="account-bar">${state.session?`<button class="ghost bell-btn" id="notificationBell" aria-label="Notifications">🔔${unread?`<i>${unread>9?'9+':unread}</i>`:''}</button><button class="ghost" id="logout">Log out</button>`:''}</div></header><main class="view">${content}</main>${nav?navHTML():''}</div>`;
  document.getElementById('brand')?.addEventListener('click',()=>state.me?go('discover'):renderLanding());
  document.getElementById('logout')?.addEventListener('click',logout);
  document.getElementById('notificationBell')?.addEventListener('click',openNotifications);
  if(nav) bindNav();
}
function navHTML(){return `<nav class="bottom-nav">${[['discover','♡','Discover'],['matches','🐾','Matches'],['messages','◌','Messages'],['profile','◉','Profile']].map(([v,i,l])=>`<button data-view="${v}" class="${state.view===v?'active':''}"><b>${i}</b><small>${l}</small></button>`).join('')}</nav>`;}
function bindNav(){document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.view)));}
function go(view){state.view=view;if(state.chatCleanup){state.chatCleanup();state.chatCleanup=null;}if(view==='discover')renderDiscover();if(view==='matches')renderMatches();if(view==='messages')renderMessages();if(view==='profile')renderProfile();}

async function boot(){
  if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  if(api.cloudConfigured){
    state.session=await safe(()=>api.getSession());
    api.onAuthChange(async session=>{
      state.session=session;if(session){import('./push.js').then(m=>m.initNativePushNavigation()).catch(()=>{});}
      if(session&&!state.me) await enterCloud();
      if(!session){
        if(state.notificationCleanup){state.notificationCleanup();state.notificationCleanup=null;}
        state.me=null;state.profiles=[];state.matches=[];state.notifications=[];renderLanding();
      }
    });
    if(state.session) return enterCloud();
  }
  renderLanding();
}

function renderLanding(){
  state.view='discover';
  shell(`<section class="hero"><div class="hero-logo">🐾🤝</div><p class="eyebrow">DOG-FIRST DATING</p><h1>Find someone worth walking beside.</h1><p class="subcopy">Paw &amp; Hand matches the human connection, the dog connection, and the life you would actually live together.</p><div class="feature-chips"><span>♡ Human compatibility</span><span>🐾 Dog compatibility</span><span>⌁ Lifestyle fit</span><span>💬 Realtime chat</span><span>🛡 Safety controls</span></div>${api.cloudConfigured?`<button class="primary wide" id="createAccount">Create account</button><button class="secondary wide" id="signIn">Sign in</button>`:`<div class="notice"><strong>Cloud setup required for real accounts.</strong><br>Connect the included Supabase backend, then rebuild. The demo below works immediately.</div>`}<button class="ghost wide" id="demo">Explore demo</button><p class="small">18+ only. Approximate location only.</p><div class="legal-links"><a target="_blank" rel="noopener" href="${publicUrl("privacy")}">Privacy</a><a target="_blank" rel="noopener" href="${publicUrl("terms")}">Terms &amp; community rules</a><a target="_blank" rel="noopener" href="${publicUrl('delete-account')}">Account deletion</a><a target="_blank" rel="noopener" href="${publicUrl('safety')}">Safety</a><a target="_blank" rel="noopener" href="${publicUrl('support')}">Support</a></div></section>`);
  document.getElementById('createAccount')?.addEventListener('click',()=>renderAuth('signup'));
  document.getElementById('signIn')?.addEventListener('click',()=>renderAuth('signin'));
  document.getElementById('demo').addEventListener('click',()=>startDemo());
}

function renderAuth(mode='signin'){
  shell(`<section class="panel"><p class="eyebrow">PAW &amp; HAND ACCOUNT</p><h2>${mode==='signup'?'Create your account':'Welcome back'}</h2><div class="auth-tabs"><button class="secondary ${mode==='signin'?'active':''}" data-auth="signin">Sign in</button><button class="secondary ${mode==='signup'?'active':''}" data-auth="signup">Create account</button></div><form id="authForm"><label>Email<input id="email" type="email" autocomplete="email" required placeholder="you@example.com"></label><label>Password<input id="password" type="password" minlength="8" autocomplete="${mode==='signup'?'new-password':'current-password'}" required placeholder="At least 8 characters"></label>${mode==='signup'?'<label class="checkline"><input type="checkbox" required> <span>I confirm I am 18+ and agree to the <a target="_blank" rel="noopener" href="${publicUrl("terms")}">Terms &amp; community rules</a> and <a target="_blank" rel="noopener" href="${publicUrl("privacy")}">Privacy Policy</a>.</span></label>':''}<button class="primary wide" id="authSubmit">${mode==='signup'?'Create account':'Sign in'}</button></form>${mode==='signin'?'<button class="ghost wide" id="forgot">Send password reset</button>':''}<p class="small">Paw &amp; Hand is for adults 18 and older.</p><div id="authStatus"></div></section>`);
  document.querySelectorAll('[data-auth]').forEach(b=>b.addEventListener('click',()=>renderAuth(b.dataset.auth)));
  document.getElementById('authForm').addEventListener('submit',async e=>{
    e.preventDefault();const email=document.getElementById('email').value.trim();const password=document.getElementById('password').value;const btn=document.getElementById('authSubmit');setBusy(btn,true);
    const result=await safe(()=>mode==='signup'?api.signUp(email,password):api.signIn(email,password));setBusy(btn,false);
    if(!result)return;
    if(result.session){state.session=result.session;await enterCloud();}
    else {document.getElementById('authStatus').innerHTML='<p class="success">Account created. Check your email to confirm the address, then sign in.</p><button class="ghost wide" id="resendSignup">Resend verification email</button>';document.getElementById('resendSignup')?.addEventListener('click',async()=>{if(await safe(()=>api.resendVerification(email)))toast('Verification email sent.');});}
  });
  document.getElementById('forgot')?.addEventListener('click',async()=>{const email=document.getElementById('email').value.trim();if(!email)return toast('Enter your email first.');if(await safe(()=>api.resetPassword(email)))toast('Password reset email sent.');});
}

async function logout(){if(state.notificationCleanup){state.notificationCleanup();state.notificationCleanup=null;}await safe(()=>api.signOut());state={...state,session:null,me:null,profiles:[],matches:[],notifications:[],demo:false};renderLanding();}
function startDemo(){state.demo=true;state.me={id:'demo-me',...defaultMe()};state.profiles=[...demoProfiles];state.matches=[];state.demoMatched=new Set();go('discover');}

async function enterCloud(){
  if(!state.session)return renderLanding();
  shell('<div class="empty"><div class="icon">🐾</div><p>Loading your pack…</p></div>');
  const me=await safe(()=>api.getMyProfile(state.session.user.id));
  if(me){
    state.me=me;
    await refreshNotifications();
    setupNotificationSubscription();
    api.touchActive(state.me.id).catch(()=>{});
    if(state.me.moderationStatus&&state.me.moderationStatus!=='active') return renderRestricted();
    await refreshCloud();go('discover');setTimeout(()=>consumePendingPush(),0);
  }else renderOnboarding(false);
}
async function refreshCloud(){
  if(state.demo)return;
  const [profiles,matches]=await Promise.all([safe(()=>api.discoverProfiles()),safe(()=>api.listMatches(state.me.id))]);
  if(profiles)state.profiles=profiles.sort((a,b)=>compatibility(b).overall-compatibility(a).overall);
  if(matches)state.matches=matches;
  api.touchActive(state.me.id).catch(()=>{});
}
async function refreshNotifications(){
  if(state.demo||!state.session)return;
  const rows=await safe(()=>api.listNotifications(50));
  if(rows)state.notifications=rows;
}
function updateBell(){
  const bell=document.getElementById('notificationBell');if(!bell)return;
  const unread=state.notifications.filter(n=>!n.read_at).length;
  bell.innerHTML=`🔔${unread?`<i>${unread>9?'9+':unread}</i>`:''}`;
}
function setupNotificationSubscription(){
  if(state.notificationCleanup||!state.session)return;
  state.notificationCleanup=api.subscribeToNotifications(state.session.user.id,n=>{state.notifications=[n,...state.notifications.filter(x=>x.id!==n.id)].slice(0,50);updateBell();toast(n.title||'New Paw & Hand notification');});
}
function notificationFromPushData(data={}){return {id:null,read_at:new Date().toISOString(),kind:data.kind||data._kind||'message',data};}
async function consumePendingPush(){
  let raw=null;try{raw=sessionStorage.getItem('paw_push_open');if(raw)sessionStorage.removeItem('paw_push_open');}catch{}
  if(!raw||!state.me)return;
  try{await openNotificationTarget(notificationFromPushData(JSON.parse(raw)));}catch{}
}
async function openNotifications(){
  await refreshNotifications();
  const rows=state.notifications;
  modal(`<p class="eyebrow">NOTIFICATIONS</p><h3>Your latest activity</h3>${rows.length?`<div class="notification-list">${rows.map(n=>`<button class="notification-item ${n.read_at?'':'unread'}" data-notification="${n.id}"><span class="notification-icon">${n.kind==='match'?'♡':n.kind==='dog_date'?'🐾':n.kind==='safety'?'🛡':'💬'}</span><span><b>${escapeHTML(n.title)}</b><small>${escapeHTML(n.body)}</small><em>${new Date(n.created_at).toLocaleString()}</em></span></button>`).join('')}</div><button class="ghost wide" id="markAllNotifications">Mark all read</button>`:'<div class="empty"><div class="icon">🔔</div><p>No notifications yet.</p></div>'}`,()=>{
    document.querySelectorAll('[data-notification]').forEach(b=>b.addEventListener('click',()=>openNotificationTarget(rows.find(n=>n.id===b.dataset.notification))));
    document.getElementById('markAllNotifications')?.addEventListener('click',async()=>{const ids=state.notifications.filter(n=>!n.read_at).map(n=>n.id);if(ids.length)await safe(()=>api.markNotificationsRead(ids));state.notifications=state.notifications.map(n=>({...n,read_at:n.read_at||new Date().toISOString()}));updateBell();closeModal();});
  });
}
async function openNotificationTarget(n){
  if(!n)return;
  if(n.id&&!n.read_at){await safe(()=>api.markNotificationsRead([n.id]));n.read_at=new Date().toISOString();updateBell();}
  closeModal();
  if(n.kind==='safety'||n.kind==='account'){openSafetyCenter();return;}
  const matchId=n.data?.match_id;
  if(matchId){if(!state.matches.some(m=>m.id===matchId)){const list=await safe(()=>api.listMatches(state.me.id));if(list)state.matches=list;}const match=state.matches.find(m=>m.id===matchId);if(match){if(n.kind==='match')return openMatchMoment(match.other);return renderChat(match);}}
  go('matches');
}
function renderRestricted(){
  const banned=state.me?.moderationStatus==='banned';
  shell(`<section class="panel"><p class="eyebrow">ACCOUNT SAFETY STATUS</p><h2>${banned?'Account banned':'Account suspended'}</h2><div class="notice danger-note">${banned?'This account is not currently permitted to use Paw & Hand.':'This account is temporarily restricted while a safety or policy issue is reviewed.'}</div><p>Discovery, matching and messaging are disabled while this restriction is active.</p><p class="small">For an appeal or questions, contact <a href="mailto:mopo39999@gmail.com">mopo39999@gmail.com</a>.</p><button class="ghost wide" id="restrictedLogout">Log out</button></section>`);
  document.getElementById('restrictedLogout').addEventListener('click',logout);
}

function renderOnboarding(editing=false){
  const base=editing&&state.me?structuredClone(state.me):defaultMe();
  base.preferredDogSizes=base.preferredDogSizes?.length?base.preferredDogSizes:['Small','Medium','Large','Extra large'];
  base.preferredDogEnergies=base.preferredDogEnergies?.length?base.preferredDogEnergies:['Low','Medium','High'];
  base.ageMin=base.ageMin??18;base.ageMax=base.ageMax??99;
  let step=1,draft=base,humanBlob=null,dogBlob=null,humanPreview=base.humanPhoto||null,dogPreview=base.dogPhoto||base.dog?.photo||null;
  const draw=()=>{
    const pct=step*20;let body='';
    if(step===1)body=`<p class="eyebrow">ABOUT YOU</p><h2>Start with the human.</h2><div class="grid2"><label>Name<input id="name" value="${escapeHTML(draft.name||'')}" maxlength="30" required></label><label>Age<input id="age" type="number" min="18" max="99" value="${draft.age||''}" required></label></div><div class="grid2"><label>I am${select('gender',['Man','Woman','Nonbinary'],draft.gender)}</label><label>Show me${select('showMe',['Women','Men','Everyone'],draft.showMe)}</label></div><label>Looking for${select('lookingFor',['Long-term relationship','Relationship, open to seeing where it goes','Dating','Friends with dogs'],draft.lookingFor)}</label><label>Approximate location<input id="locationLabel" maxlength="60" value="${escapeHTML(draft.locationLabel||'')}" placeholder="Example: Syracuse area"></label><label>Bio<textarea id="bio" maxlength="300">${escapeHTML(draft.bio||'')}</textarea></label>`;
    if(step===2)body=`<p class="eyebrow">YOUR DOG</p><h2>Now the important part.</h2><div class="grid2"><label>Dog's name<input id="dogName" value="${escapeHTML(draft.dog.name||'')}" maxlength="30" required></label><label>Breed<input id="dogBreed" value="${escapeHTML(draft.dog.breed||'')}" maxlength="60"></label></div><div class="grid2"><label>Age<input id="dogAge" type="number" min="0" max="30" value="${draft.dog.age??''}"></label><label>Size${select('dogSize',['Small','Medium','Large','Extra large'],draft.dog.size)}</label></div><div class="grid2"><label>Energy${select('dogEnergy',['Low','Medium','High'],draft.dog.energy)}</label><label>Temperament${select('dogTemperament',['Easygoing','Friendly','Playful','Shy','Selective with dogs'],draft.dog.temperament)}</label></div><label>Meeting new dogs${select('goodWith',['Most dogs','Small dogs','Large dogs','Slow introductions'],draft.dog.goodWith)}</label>`;
    if(step===3)body=`<p class="eyebrow">LIFESTYLE</p><h2>What does life together look like?</h2><label>Things you enjoy</label><div class="choice-grid">${activities.map(a=>`<button type="button" data-activity="${a}" class="${draft.activities.includes(a)?'active':''}">${a}</button>`).join('')}</div><div class="grid2"><label>Kids${select('kids',['No preference','I have kids','I want kids someday',"I don't want kids"],draft.kids)}</label><label>Smoking${select('smoking',['Non-smoker','Occasionally','Smoker','No preference'],draft.smoking)}</label></div><label>Typical pace${select('pace',['Balanced','Active & outdoorsy','Relaxed & home-centered','Always on the go'],draft.pace)}</label>`;
    if(step===4)body=`<p class="eyebrow">MATCH PREFERENCES</p><h2>Set the real dealbreakers.</h2><div class="grid2"><label>Age from<input id="ageMin" type="number" min="18" max="99" value="${draft.ageMin}"></label><label>Age to<input id="ageMax" type="number" min="18" max="99" value="${draft.ageMax}"></label></div><label>Dog sizes you're comfortable meeting</label><div class="choice-grid">${['Small','Medium','Large','Extra large'].map(x=>`<button type="button" data-pref-size="${x}" class="${draft.preferredDogSizes.includes(x)?'active':''}">${x}</button>`).join('')}</div><label>Dog energy levels that fit your household</label><div class="choice-grid">${['Low','Medium','High'].map(x=>`<button type="button" data-pref-energy="${x}" class="${draft.preferredDogEnergies.includes(x)?'active':''}">${x}</button>`).join('')}</div><label class="checkline"><input id="avoidSmokers" type="checkbox" ${draft.avoidSmokers?'checked':''}> <span>Don't show smokers</span></label><label class="checkline"><input id="requireSharedActivity" type="checkbox" ${draft.requireSharedActivity?'checked':''}> <span>Require at least one shared activity</span></label><div class="notice"><strong>Reciprocal filtering.</strong> Paw &amp; Hand only shows a profile when both people satisfy each other's age, gender, smoking, and dog-fit preferences.</div>`;
    if(step===5)body=`<p class="eyebrow">MATCH PRIORITIES + PHOTOS</p><h2>What matters most?</h2>${weight('people','♡ People compatibility',draft.weights.people)}${weight('dog','🐾 Dog compatibility',draft.weights.dog)}${weight('lifestyle','⌁ Lifestyle fit',draft.weights.lifestyle)}<div class="photo-pair"><div><label>Your photo</label><div class="photo-preview" id="humanPreview">${humanPreview?`<img src="${humanPreview}">`:'🙂'}</div><label class="upload"><input id="humanPhoto" type="file" accept="image/*">Choose photo</label></div><div><label>Dog photo</label><div class="photo-preview" id="dogPreview">${dogPreview?`<img src="${dogPreview}">`:'🐾'}</div><label class="upload"><input id="dogPhoto" type="file" accept="image/*">Choose photo</label></div></div><div class="notice">Photos are resized before upload. Backend storage is private and precise GPS is not required.</div>`;
    shell(`<section class="panel"><div class="wizard-progress"><i style="width:${pct}%"></i></div>${body}<div class="wizard-nav"><button class="secondary" id="back" ${step===1?'disabled':''}>Back</button><button class="primary" id="next">${step===5?(editing?'Save changes':'Finish profile'):'Continue'}</button></div></section>`);
    document.getElementById('back').addEventListener('click',()=>{capture();step--;draw();});
    document.getElementById('next').addEventListener('click',async()=>{if(!capture(true))return;if(step<5){step++;draw();return;}const btn=document.getElementById('next');setBusy(btn,true,'Saving…');if(state.demo){draft.id='demo-me';draft.humanPhoto=humanPreview;draft.dogPhoto=dogPreview;state.me=draft;setBusy(btn,false);go('discover');return;}draft.humanPhotoBlob=humanBlob;draft.dogPhotoBlob=dogBlob;draft.photoPath=state.me?.photoPath;draft.dogPhotoPath=state.me?.dogPhotoPath;const saved=await safe(()=>api.saveProfile(state.session.user.id,draft));setBusy(btn,false);if(saved){state.me=saved;await refreshCloud();go('discover');setTimeout(()=>consumePendingPush(),0);}});
    document.querySelectorAll('[data-activity]').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('active');const a=b.dataset.activity;draft.activities=b.classList.contains('active')?[...new Set([...draft.activities,a])]:draft.activities.filter(x=>x!==a);}));
    document.querySelectorAll('[data-pref-size]').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('active');const x=b.dataset.prefSize;draft.preferredDogSizes=b.classList.contains('active')?[...new Set([...draft.preferredDogSizes,x])]:draft.preferredDogSizes.filter(v=>v!==x);}));
    document.querySelectorAll('[data-pref-energy]').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('active');const x=b.dataset.prefEnergy;draft.preferredDogEnergies=b.classList.contains('active')?[...new Set([...draft.preferredDogEnergies,x])]:draft.preferredDogEnergies.filter(v=>v!==x);}));
    document.getElementById('humanPhoto')?.addEventListener('change',async e=>{const result=await compressImage(e.target.files[0]);if(result){humanBlob=result.blob;humanPreview=result.url;document.getElementById('humanPreview').innerHTML=`<img src="${result.url}">`;}});
    document.getElementById('dogPhoto')?.addEventListener('change',async e=>{const result=await compressImage(e.target.files[0]);if(result){dogBlob=result.blob;dogPreview=result.url;document.getElementById('dogPreview').innerHTML=`<img src="${result.url}">`;}});
  };
  const capture=(validate=false)=>{
    if(step===1){draft.name=val('name');draft.age=Number(val('age'));draft.gender=val('gender');draft.showMe=val('showMe');draft.lookingFor=val('lookingFor');draft.locationLabel=val('locationLabel');draft.bio=val('bio');if(validate&&(!draft.name||draft.age<18)){toast('Enter a name and an age of 18 or older.');return false;}if(validate&&!contentCheck(draft.name,draft.locationLabel,draft.bio))return false;}
    if(step===2){draft.dog={...draft.dog,name:val('dogName'),breed:val('dogBreed'),age:Number(val('dogAge')||0),size:val('dogSize'),energy:val('dogEnergy'),temperament:val('dogTemperament'),goodWith:val('goodWith')};if(validate&&!draft.dog.name){toast("Enter your dog's name.");return false;}if(validate&&!contentCheck(draft.dog.name,draft.dog.breed))return false;}
    if(step===3){draft.kids=val('kids');draft.smoking=val('smoking');draft.pace=val('pace');}
    if(step===4){draft.ageMin=Number(val('ageMin'));draft.ageMax=Number(val('ageMax'));draft.avoidSmokers=Boolean(document.getElementById('avoidSmokers')?.checked);draft.requireSharedActivity=Boolean(document.getElementById('requireSharedActivity')?.checked);if(validate&&(draft.ageMin<18||draft.ageMax>99||draft.ageMin>draft.ageMax)){toast('Choose a valid age range.');return false;}if(validate&&!draft.preferredDogSizes.length){toast('Choose at least one dog size.');return false;}if(validate&&!draft.preferredDogEnergies.length){toast('Choose at least one dog energy level.');return false;}}
    if(step===5)draft.weights={people:Number(val('peopleWeight')),dog:Number(val('dogWeight')),lifestyle:Number(val('lifestyleWeight'))};
    return true;
  };
  draw();
}
function select(id,opts,current){return `<select id="${id}">${opts.map(o=>`<option ${o===current?'selected':''}>${escapeHTML(o)}</option>`).join('')}</select>`;}
function weight(id,label,value){return `<label>${label} <span class="small" id="${id}Out">${value}/5</span><input id="${id}Weight" type="range" min="1" max="5" value="${value}" oninput="document.getElementById('${id}Out').textContent=this.value+'/5'"></label>`;}
const val=id=>document.getElementById(id)?.value??'';

async function compressImage(file){
  if(!file)return null;const data=await file.arrayBuffer();const blob=new Blob([data],{type:file.type});const url=URL.createObjectURL(blob);const img=new Image();img.src=url;await img.decode();const max=900;const scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);URL.revokeObjectURL(url);const out=await new Promise(r=>canvas.toBlob(r,'image/jpeg',.78));return {blob:out,url:URL.createObjectURL(out)};
}

function compatibility(other){
  const me=state.me||defaultMe();
  const reasons=[],cautions=[];
  const goalExact=me.lookingFor===other.lookingFor;
  const bothRelationship=String(me.lookingFor).toLowerCase().includes('relationship')&&String(other.lookingFor).toLowerCase().includes('relationship');
  const peopleGoal=goalExact?30:bothRelationship?24:14;
  if(goalExact) reasons.push('Same relationship goal'); else if(bothRelationship) reasons.push('Compatible relationship intent'); else cautions.push('Different dating goals');
  const kidsAligned=me.kids==='No preference'||other.kids==='No preference'||me.kids===other.kids;
  const kids=kidsAligned?20:8;if(kidsAligned) reasons.push('Family preferences line up'); else cautions.push('Different family preferences');
  const smokeAligned=me.smoking==='No preference'||other.smoking==='No preference'||me.smoking===other.smoking;
  const smoke=smokeAligned?15:6;if(!smokeAligned)cautions.push('Different smoking preferences');
  const ageGap=Math.abs(Number(me.age||0)-Number(other.age||0));
  const ageScore=ageGap<=5?15:ageGap<=10?12:ageGap<=15?9:6;
  const meMin=Number(me.ageMin??18),meMax=Number(me.ageMax??99),otherMin=Number(other.ageMin??18),otherMax=Number(other.ageMax??99);
  const reciprocalAge=other.age>=meMin&&other.age<=meMax&&me.age>=otherMin&&me.age<=otherMax;
  const reciprocity=reciprocalAge?20:5;if(reciprocalAge)reasons.push('Mutual age preferences fit');
  const people=Math.max(0,Math.min(100,peopleGoal+kids+smoke+ageScore+reciprocity));

  const energyOrder=['Low','Medium','High'];
  const energyGap=Math.abs(energyOrder.indexOf(me.dog.energy)-energyOrder.indexOf(other.dog.energy));
  const energy=energyGap===0?35:energyGap===1?25:10;
  const social=(me.dog.goodWith==='Most dogs'||other.dog.goodWith==='Most dogs'||me.dog.goodWith===other.dog.goodWith)?30:17;
  const size=me.dog.size===other.dog.size?20:((me.preferredDogSizes||[]).includes(other.dog.size)&&(other.preferredDogSizes||['Small','Medium','Large','Extra large']).includes(me.dog.size)?17:7);
  const temperament=me.dog.temperament===other.dog.temperament?15:(['Friendly','Easygoing'].includes(me.dog.temperament)&&['Friendly','Easygoing'].includes(other.dog.temperament)?13:9);
  const dog=Math.max(0,Math.min(100,energy+social+size+temperament));
  if(energyGap===0)reasons.push('Dogs have similar energy'); else if(energyGap>1)cautions.push('Dogs have very different energy');
  if(social>=30)reasons.push('Dog social styles look compatible');

  const mine=me.activities||[],theirs=other.activities||[];
  const overlapList=mine.filter(x=>theirs.includes(x));
  const union=new Set([...mine,...theirs]).size||1;
  const activityScore=Math.round(50*(overlapList.length/union));
  const pace=me.pace===other.pace?30:20;
  const a=String(me.locationLabel||'').toLowerCase().split(/\W+/).filter(x=>x.length>2),b=String(other.locationLabel||'').toLowerCase().split(/\W+/).filter(x=>x.length>2);
  const locationOverlap=a.some(x=>b.includes(x));
  const location=locationOverlap?20:10;
  const lifestyle=Math.max(0,Math.min(100,activityScore+pace+location));
  if(overlapList.length)reasons.push(`${overlapList.length} shared ${overlapList.length===1?'activity':'activities'}`); else cautions.push('Few listed activities in common');
  if(me.pace===other.pace)reasons.push('Similar everyday pace');

  const w=me.weights||{people:4,dog:5,lifestyle:3};
  const overall=Math.round((people*w.people+dog*w.dog+lifestyle*w.lifestyle)/(w.people+w.dog+w.lifestyle));
  return {people,dog,lifestyle,overall,overlap:overlapList.length,overlapList,reasons:[...new Set(reasons)].slice(0,5),cautions:[...new Set(cautions)].slice(0,4)};
}

function renderDiscover(){
  const p=state.profiles[0];
  const remaining=state.profiles.length;
  const queueNote=p?`<div class="discover-status"><span><b>${remaining}</b> ${remaining===1?'profile':'profiles'} fit your reciprocal preferences</span><span>Best fit first</span></div>`:'';
  const emptyCopy=state.demo
    ? '<div class="empty compact-empty"><div class="icon">🐾</div><h3>Demo profiles are finished.</h3><p>You made it through the sample pack.</p></div>'
    : '<div class="empty compact-empty"><div class="icon">🐾</div><h3>Your profile is live.</h3><p>No new reciprocal matches are available yet. Paw &amp; Hand only shows people when both sides fit each other&#39;s age, gender, smoking, activity, and dog preferences.</p><button class="secondary" id="reload">Check again</button><p class="small">As more people join, matching profiles will appear here automatically.</p></div>';
  shell(`<section><div class="section-head"><div><p class="eyebrow">DISCOVER</p><h2>Good humans. Good dogs.</h2></div>${!state.demo?'<button class="ghost" id="refresh">Refresh</button>':''}</div>${queueNote}${p?profileCard(p):emptyCopy}</section>`,{nav:true});
  document.getElementById('refresh')?.addEventListener('click',async()=>{await refreshCloud();renderDiscover();});
  document.getElementById('reload')?.addEventListener('click',async()=>{await refreshCloud();renderDiscover();});
  if(!p)return;
  document.getElementById('details').addEventListener('click',()=>openCompatibility(p));
  document.getElementById('pass').addEventListener('click',()=>swipe(p,'pass'));
  document.getElementById('like').addEventListener('click',()=>swipe(p,'like'));
  document.getElementById('pawLike').addEventListener('click',()=>swipe(p,'paw_like'));
  document.getElementById('block').addEventListener('click',()=>openSafety(p));
}
function profileCard(p){
  const c=compatibility(p);
  const dogName=p.dog?.name||'Dog';
  return `<article class="panel profile-card">
    <div class="profile-photo">${p.humanPhoto?`<img src="${p.humanPhoto}" alt="${escapeHTML(p.name)}">`:'🙂'}<div class="photo-fit">${c.overall}% fit</div></div>
    <div class="profile-body">
      <div class="profile-title"><div><h2>${escapeHTML(p.name)}, ${p.age}</h2><div class="location">${escapeHTML(p.locationLabel||'Approximate area hidden')} · ${escapeHTML(p.lookingFor)}</div></div></div>
      <p class="profile-bio">${escapeHTML(p.bio)}</p>
      <button class="why-match-btn" id="details"><span>Why this match?</span><b>${c.people}% human · ${c.dog}% dog · ${c.lifestyle}% lifestyle</b></button>
      <div class="dog-box"><div class="dog-row"><div class="avatar">${p.dogPhoto?`<img src="${p.dogPhoto}" alt="${escapeHTML(dogName)}">`:'🐾'}</div><div><strong>${escapeHTML(dogName)}</strong><div class="small">${escapeHTML(p.dog?.breed||'Breed not listed')} · ${Number(p.dog?.age??0)} yrs</div><div class="small">${escapeHTML(p.dog?.size||'Size not listed')} · ${escapeHTML(p.dog?.energy||'Energy not listed')} energy · ${escapeHTML(p.dog?.temperament||'Temperament not listed')}</div></div></div></div>
      <div class="actions action-dock">
        <button class="round action-with-label" id="block" aria-label="Safety options"><span>⋯</span><small>Safety</small></button>
        <button class="round action-with-label" id="pass" aria-label="Pass"><span>×</span><small>Pass</small></button>
        <button class="round paw action-with-label" id="pawLike" aria-label="Paw Like"><span>🐾</span><small>Paw like</small></button>
        <button class="round like action-with-label" id="like" aria-label="Like"><span>♡</span><small>Like</small></button>
      </div>
    </div>
  </article>`;
}

async function swipe(p,action){
  state.profiles=state.profiles.filter(x=>x.id!==p.id);
  if(state.demo){if(action!=='pass'){state.demoMatched.add(p.id);state.matches=[...state.demoMatched].map(id=>({id:`match-${id}`,other:demoProfiles.find(x=>x.id===id)}));if(action==='paw_like'||state.demoMatched.size%2===1)openMatchMoment(p);}renderDiscover();return;}
  renderDiscover();const match=await safe(()=>api.recordSwipe(state.me.id,p.id,action));if(action!=='pass'&&match){await refreshCloud();openMatchMoment(p);}
}
function openMatchMoment(p){const c=compatibility(p);modal(`<div style="text-align:center"><div style="font-size:54px">🐾♡🐾</div><p class="eyebrow">IT'S A MATCH</p><h2>You + ${escapeHTML(p.name)}</h2><p class="subcopy">And the dogs look promising too.</p><div class="score-row"><div class="score"><b>${c.people}%</b><small>People</small></div><div class="score"><b>${c.dog}%</b><small>Dogs</small></div><div class="score"><b>${c.lifestyle}%</b><small>Lifestyle</small></div></div><button class="primary wide" id="matchMessage">Send a message</button><button class="secondary wide" id="matchDate">Suggest a Dog Date</button></div>`,()=>{document.getElementById('matchMessage').addEventListener('click',()=>{closeModal();openChatByUser(p.id);});document.getElementById('matchDate').addEventListener('click',()=>{closeModal();openDogDateByUser(p.id);});});}
function openCompatibility(p){const c=compatibility(p);modal(`<p class="eyebrow">MATCH BREAKDOWN</p><h3>${escapeHTML(p.name)} + ${escapeHTML(p.dog.name)}</h3><div class="compat-list">${compatRow('♡ People compatibility',c.people,'Dating goals, family preferences, age fit and everyday choices.')}${compatRow('🐾 Dog compatibility',c.dog,'Energy, social style, size preferences and temperament.')}${compatRow('⌁ Lifestyle compatibility',c.lifestyle,`${c.overlap} shared ${c.overlap===1?'activity':'activities'}, pace, and approximate-area fit.`)}</div>${c.reasons.length?`<div class="match-insights good"><b>Why it works</b><ul>${c.reasons.map(x=>`<li>${escapeHTML(x)}</li>`).join('')}</ul></div>`:''}${c.cautions.length?`<div class="match-insights caution"><b>Worth talking about</b><ul>${c.cautions.map(x=>`<li>${escapeHTML(x)}</li>`).join('')}</ul></div>`:''}<button class="primary wide" id="compatClose">Got it</button>`,()=>document.getElementById('compatClose').addEventListener('click',closeModal));}
function compatRow(label,score,text){return `<div class="compat"><strong>${label}</strong><span style="float:right">${score}%</span><div class="meter"><i style="width:${score}%"></i></div><div class="small">${escapeHTML(text)}</div></div>`;}

async function renderMatches(){
  if(!state.demo){const m=await safe(()=>api.listMatches(state.me.id));if(m)state.matches=m;}
  shell(`<section><div class="section-head"><div><p class="eyebrow">MATCHES</p><h2>Your pack.</h2></div></div>${state.matches.length?state.matches.map(m=>matchRow(m)).join(''):'<div class="empty"><div class="icon">♡</div><h3>No matches yet.</h3><p>When interest goes both ways, the match appears here.</p></div>'}</section>`,{nav:true});
  document.querySelectorAll('[data-chat]').forEach(b=>b.addEventListener('click',()=>openChatByUser(b.dataset.chat)));document.querySelectorAll('[data-date]').forEach(b=>b.addEventListener('click',()=>openDogDateByUser(b.dataset.date)));
}
function matchRow(m){const p=m.other,c=compatibility(p);return `<div class="match-card"><div class="avatar">${p.humanPhoto?`<img src="${p.humanPhoto}">`:'🙂'}</div><div class="copy"><strong>${escapeHTML(p.name)} + ${escapeHTML(p.dog.name)}</strong><span>${c.overall}% overall · ${c.dog}% dog fit</span></div><button class="ghost" data-date="${p.id}">🐾</button><button class="primary" data-chat="${p.id}">Message</button></div>`;}

async function renderMessages(){
  if(!state.demo){const m=await safe(()=>api.listMatches(state.me.id));if(m)state.matches=m;}
  const rows=[];for(const m of state.matches){let last='New match — say hello';if(state.demo){const arr=state.demoChats[m.id]||[];last=arr.at(-1)?.body||last;}else{const msgs=await safe(()=>api.listMessages(m.id));last=msgs?.at(-1)?.body||last;}rows.push(`<button class="message-row" data-open="${m.other.id}" style="width:100%;color:inherit;text-align:left"><div class="avatar">${m.other.humanPhoto?`<img src="${m.other.humanPhoto}">`:'🙂'}</div><div class="copy"><strong>${escapeHTML(m.other.name)} + ${escapeHTML(m.other.dog.name)}</strong><span>${escapeHTML(last)}</span></div><span class="badge">${compatibility(m.other).dog}% 🐾</span></button>`);}
  shell(`<section><div class="section-head"><div><p class="eyebrow">MESSAGES</p><h2>Keep it moving.</h2></div></div>${rows.length?rows.join(''):'<div class="empty"><div class="icon">◌</div><h3>No conversations yet.</h3><p>Your matches will show up here.</p></div>'}</section>`,{nav:true});document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openChatByUser(b.dataset.open)));
}
function findMatchByUser(userId){return state.matches.find(m=>m.other?.id===userId);}
async function openChatByUser(userId){let m=findMatchByUser(userId);if(!m&&!state.demo){const list=await api.listMatches(state.me.id);state.matches=list;m=findMatchByUser(userId);}if(!m)return toast('Match not available.');renderChat(m);}
async function renderChat(match){
  const p=match.other;let messages=state.demo?(state.demoChats[match.id]||[]):await safe(()=>api.listMessages(match.id))||[];
  const draw=()=>{const box=document.getElementById('messages');if(!box)return;box.innerHTML=messages.map(x=>{const mine=x.sender_id===state.me.id||x.sender_id==='me';return `<div class="bubble-wrap ${mine?'mine':''}"><div class="bubble ${mine?'me':''}">${escapeHTML(x.body)}</div>${mine?'':`<button class="bubble-report" data-report-message="${escapeHTML(x.id||'')}" aria-label="Report message" title="Report message">⋯</button>`}</div>`;}).join('');box.querySelectorAll('[data-report-message]').forEach(b=>b.addEventListener('click',()=>openSafety(p,{matchId:match.id,messageId:b.dataset.reportMessage||null})));box.scrollTop=box.scrollHeight;};
  shell(`<section class="chat"><div class="chat-head"><button class="ghost" id="chatBack">←</button><div class="avatar">${p.humanPhoto?`<img src="${p.humanPhoto}">`:'🙂'}</div><div class="copy"><strong>${escapeHTML(p.name)} + ${escapeHTML(p.dog.name)}</strong><span>${compatibility(p).overall}% fit</span></div><button class="ghost" id="chatSafety" aria-label="Conversation safety">⋯</button><button class="ghost" id="dateBtn">🐾 Date</button></div><div class="notice safety-mini">Never send money or financial credentials. Keep a first Dog Date public and report anything that feels unsafe.</div><div class="feature-chips"><span data-prompt>What is ${escapeHTML(p.dog.name)}'s perfect Saturday?</span><span data-prompt>Walk or coffee first?</span></div><div class="messages" id="messages"></div><form class="compose" id="compose"><input id="message" maxlength="1000" autocomplete="off" placeholder="Message your match…"><button class="primary">Send</button></form></section>`,{nav:true});draw();
  document.getElementById('chatBack').addEventListener('click',()=>go('messages'));document.getElementById('dateBtn').addEventListener('click',()=>openDogDate(match));document.getElementById('chatSafety').addEventListener('click',()=>openSafety(p,{matchId:match.id}));document.querySelectorAll('[data-prompt]').forEach(x=>x.addEventListener('click',()=>{document.getElementById('message').value=x.textContent;}));
  document.getElementById('compose').addEventListener('submit',async e=>{e.preventDefault();const input=document.getElementById('message');const body=input.value.trim();if(!body)return;if(!contentCheck(body))return;input.value='';if(state.demo){const msg={id:`demo-${Date.now()}`,sender_id:'me',body};messages.push(msg);state.demoChats[match.id]=messages;draw();setTimeout(()=>{messages.push({id:`demo-${Date.now()}-reply`,sender_id:'them',body:`That sounds good — ${p.dog.name} is in 🐾`});state.demoChats[match.id]=messages;draw();},350);}else{await safe(()=>api.sendMessage(match.id,state.me.id,body));}});
  if(!state.demo){state.chatCleanup=api.subscribeToMessages(match.id,msg=>{if(!messages.some(x=>x.id===msg.id)){messages.push(msg);draw();}});}
}

function openDogDateByUser(userId){const m=findMatchByUser(userId);if(!m)return toast('Open a current match first.');openDogDate(m);}
function openDogDate(match){const min=new Date(Date.now()+3600000).toISOString().slice(0,16);modal(`<p class="eyebrow">DOG DATE MODE</p><h3>Plan something easy with ${escapeHTML(match.other.name)} + ${escapeHTML(match.other.dog.name)}</h3><label>Place<input id="datePlace" maxlength="120" placeholder="Dog park, trail, dog-friendly cafe…"></label><label>Date &amp; time<input id="dateTime" type="datetime-local" min="${min}"></label><label>Note<textarea id="dateNote" maxlength="300" placeholder="Short walk first? Meet by the main entrance?"></textarea></label><div class="notice">For safety, meet in a public place and keep first-meet location details inside the match conversation.</div><button class="primary wide" id="sendDate">Send Dog Date idea</button>`,()=>document.getElementById('sendDate').addEventListener('click',async()=>{const place=val('datePlace').trim();if(!place)return toast('Add a meeting place.');const dateTime=val('dateTime'),note=val('dateNote');if(!contentCheck(place,note))return;if(state.demo){const body=`🐾 Dog Date idea: ${place}${dateTime?' on '+new Date(dateTime).toLocaleString():''}. ${note||'Want to meet there with the dogs?'}`;const arr=state.demoChats[match.id]||[];arr.push({sender_id:'me',body});state.demoChats[match.id]=arr;closeModal();toast('Dog Date sent.');return;}const sent=await safe(()=>api.proposeDogDate(match.id,state.me.id,{place,dateTime,note}));if(sent){closeModal();toast('Dog Date sent.');}}));}

function openSafety(p,context={}){
  const contextNote=context.messageId?'The selected message will be attached to this report.':context.matchId?'This conversation will be attached to this report.':'The profile will be attached to this report.';
  modal(`<p class="eyebrow">SAFETY &amp; REPORTING</p><h3>${escapeHTML(p.name)}</h3><div class="notice">${contextNote} Reporting does not automatically block the person, so you can choose either action.</div><button class="danger wide" id="blockUser">Block &amp; remove this match</button><label>Report reason${select('reportReason',['Harassment','Spam or scam','Fake profile','Underage concern','Sexual exploitation','Threats or violence','Hate or discrimination','Unsafe behavior','Other'],'Unsafe behavior')}</label><label>Details<textarea id="reportDetails" maxlength="1000" placeholder="Tell the moderation team what happened"></textarea></label><button class="secondary wide" id="reportUser">Submit report</button><button class="ghost wide" id="safetyTips">Open safety center</button>`,()=>{
    document.getElementById('blockUser').addEventListener('click',async()=>{if(state.demo){state.profiles=state.profiles.filter(x=>x.id!==p.id);state.matches=state.matches.filter(x=>x.other?.id!==p.id);closeModal();return go('discover');}const done=await safe(()=>api.blockUser(state.me.id,p.id));if(done===null)return;state.profiles=state.profiles.filter(x=>x.id!==p.id);state.matches=state.matches.filter(x=>x.other?.id!==p.id);closeModal();go('discover');toast('Person blocked and removed.');});
    document.getElementById('reportUser').addEventListener('click',async()=>{if(state.demo){closeModal();return toast('Demo report recorded locally.');}const ok=await safe(()=>api.reportUser(state.me.id,p.id,val('reportReason'),val('reportDetails'),context));if(ok){closeModal();toast('Report submitted for review.');}});
    document.getElementById('safetyTips').addEventListener('click',()=>{closeModal();openSafetyCenter();});
  });
}

function openSafetyCenter(){
  modal(`<p class="eyebrow">SAFETY CENTER</p><h3>Meet people. Protect yourself and your dog.</h3><div class="safety-grid"><div class="safety-card"><b>💬 Keep control of contact</b><p>Use Paw &amp; Hand chat until you are comfortable. Never send passwords, verification codes, banking details, gift cards, crypto, or money to a match.</p></div><div class="safety-card"><b>📍 First meetings stay public</b><p>Pick a busy public location, tell someone your plan, arrange your own transportation, and leave if anything feels wrong.</p></div><div class="safety-card"><b>🐾 Introduce dogs carefully</b><p>Start on neutral ground, use leashes when appropriate, respect each dog's body language, and do not force an interaction.</p></div><div class="safety-card"><b>🛡 Report and block</b><p>Profiles and conversations have report/block controls. Reports can reference the specific conversation or message that caused concern.</p></div></div><button class="primary wide" id="safetyDone">Got it</button>`,()=>document.getElementById('safetyDone').addEventListener('click',closeModal));
}

function renderProfile(){
  const p=state.me,c=p.weights||{people:4,dog:5,lifestyle:3},visible=p.isVisible!==false;
  const prefSizes=(p.preferredDogSizes||[]).join(', '),prefEnergy=(p.preferredDogEnergies||[]).join(', ');
  shell(`<section class="panel"><div class="section-head"><div><p class="eyebrow">PROFILE</p><h2>You + your dog.</h2></div><button class="secondary" id="edit">Edit</button></div><div class="match-card"><div class="avatar">${p.humanPhoto?`<img src="${p.humanPhoto}">`:'🙂'}</div><div class="copy"><strong>${escapeHTML(p.name)}, ${p.age}</strong><span>${escapeHTML(p.lookingFor)} · ${escapeHTML(p.locationLabel||'Approximate area hidden')}</span></div></div><div class="profile-section"><h3>About me</h3><p>${escapeHTML(p.bio)}</p><div class="feature-chips">${p.activities.map(a=>`<span>${escapeHTML(a)}</span>`).join('')}</div></div><div class="profile-section"><h3>My dog</h3><p><strong>${escapeHTML(p.dog.name)}</strong> · ${escapeHTML(p.dog.breed)} · ${p.dog.age} yrs</p><p class="small">${escapeHTML(p.dog.size)} · ${escapeHTML(p.dog.energy)} energy · ${escapeHTML(p.dog.temperament)} · ${escapeHTML(p.dog.goodWith)}</p></div><div class="profile-section"><h3>Who should appear</h3><div class="preference-summary"><span><b>${p.ageMin??18}–${p.ageMax??99}</b><small>Age range</small></span><span><b>${p.avoidSmokers?'No smokers':'Flexible'}</b><small>Smoking</small></span><span><b>${p.requireSharedActivity?'Required':'Preferred'}</b><small>Shared activity</small></span></div><p class="small"><strong>Dog sizes:</strong> ${escapeHTML(prefSizes)}<br><strong>Dog energy:</strong> ${escapeHTML(prefEnergy)}</p></div><div class="profile-section"><h3>Match priorities</h3><div class="score-row"><div class="score"><b>${c.people}/5</b><small>People</small></div><div class="score"><b>${c.dog}/5</b><small>Dogs</small></div><div class="score"><b>${c.lifestyle}/5</b><small>Lifestyle</small></div></div></div><div class="profile-section"><h3>Account &amp; privacy</h3><p class="small">Paw &amp; Hand uses approximate location labels rather than requiring precise GPS. Profile media is kept in private storage and served with expiring signed links.</p>${state.demo?'<div class="notice">You are exploring demo mode. Connect Supabase to create a persistent account.</div>':`<button class="secondary wide" id="visibilityBtn">${visible?'Pause discovery':'Resume discovery'}</button><button class="secondary wide" id="notificationSettingsBtn">Notifications &amp; push</button><button class="secondary wide" id="accountSecurityBtn">Account security</button><button class="ghost wide" id="privacyBtn">Privacy policy</button><button class="ghost wide" id="rulesBtn">Terms &amp; community rules</button><button class="ghost wide" id="safetyCenterBtn">Safety center</button><button class="ghost wide" id="logoutProfile">Log out</button><button class="danger wide" id="deleteAccountBtn">Delete account &amp; data</button>`}</div></section>`,{nav:true});
  document.getElementById('edit').addEventListener('click',()=>renderOnboarding(true));
  document.getElementById('logoutProfile')?.addEventListener('click',logout);
  document.getElementById('visibilityBtn')?.addEventListener('click',async e=>{const next=!visible;setBusy(e.currentTarget,true);const saved=await safe(()=>api.setProfileVisibility(state.me.id,next));setBusy(e.currentTarget,false);if(saved===null||saved===undefined)return;state.me.isVisible=saved;toast(saved?'Discovery resumed.':'Profile paused.');renderProfile();});
  document.getElementById('notificationSettingsBtn')?.addEventListener('click',openNotificationSettings);
  document.getElementById('accountSecurityBtn')?.addEventListener('click',openAccountSecurity);
  document.getElementById('privacyBtn')?.addEventListener('click',()=>window.open(publicUrl('privacy'),'_blank','noopener'));
  document.getElementById('rulesBtn')?.addEventListener('click',()=>window.open(publicUrl('terms'),'_blank','noopener'));
  document.getElementById('safetyCenterBtn')?.addEventListener('click',openSafetyCenter);
  document.getElementById('deleteAccountBtn')?.addEventListener('click',confirmDeleteAccount);
}

async function openNotificationSettings(){
  const prefs=await safe(()=>api.getNotificationPreferences(state.me.id));if(!prefs)return;
  const devices=await safe(()=>api.listPushDevices())||[];
  modal(`<p class="eyebrow">NOTIFICATIONS</p><h3>Choose what should get your attention.</h3><label class="checkline"><input id="prefMatches" type="checkbox" ${prefs.new_matches?'checked':''}> <span>New matches</span></label><label class="checkline"><input id="prefMessages" type="checkbox" ${prefs.messages?'checked':''}> <span>Messages</span></label><label class="checkline"><input id="prefDates" type="checkbox" ${prefs.dog_dates?'checked':''}> <span>Dog Date ideas</span></label><label class="checkline"><input id="prefSafety" type="checkbox" ${prefs.safety?'checked':''}> <span>Safety &amp; account notices</span></label><button class="primary wide" id="saveNotificationPrefs">Save notification preferences</button><div class="profile-section"><h4>Installed-device push</h4><p class="small">Push registration only runs inside the installed Android or iPhone app. The web app still receives in-app notifications while open.</p><button class="secondary wide" id="enablePushBtn">Enable push on this device</button>${devices.length?`<div class="device-list">${devices.map(d=>`<div><span>${d.platform==='ios'?'':'Android'} device</span><small>${d.enabled?'Enabled':'Disabled'}${d.last_success_at?' · last delivered '+new Date(d.last_success_at).toLocaleDateString():''}${d.last_error?' · delivery issue':''}</small>${d.enabled?`<button class="ghost" data-disable-device="${d.id}">Disable</button>`:''}</div>`).join('')}</div>`:'<p class="small">No native push devices registered yet.</p>'}</div>`,()=>{
    document.getElementById('saveNotificationPrefs').addEventListener('click',async e=>{const btn=e.currentTarget;setBusy(btn,true,'Saving…');const saved=await safe(()=>api.saveNotificationPreferences(state.me.id,{new_matches:document.getElementById('prefMatches').checked,messages:document.getElementById('prefMessages').checked,dog_dates:document.getElementById('prefDates').checked,safety:document.getElementById('prefSafety').checked}));setBusy(btn,false);if(saved){toast('Notification preferences saved.');closeModal();}});
    document.getElementById('enablePushBtn').addEventListener('click',async e=>{const btn=e.currentTarget;setBusy(btn,true,'Registering…');try{const push=await import('./push.js');const result=await push.enableNativePush(state.me.id);toast(`Push enabled on ${result.platform}.`);closeModal();}catch(err){console.error(err);toast(err.message||'Push registration failed.');setBusy(btn,false);}});
    document.querySelectorAll('[data-disable-device]').forEach(b=>b.addEventListener('click',async e=>{const btn=e.currentTarget;setBusy(btn,true,'Disabling…');const ok=await safe(()=>api.disablePushDevice(btn.dataset.disableDevice));if(ok){toast('Push disabled for that device.');closeModal();}}));
  });
}

async function openAccountSecurity(){
  const user=await safe(()=>api.getCurrentUser());if(!user)return;
  const confirmed=Boolean(user.email_confirmed_at);
  const role=String(user.app_metadata?.role||'');
  const isOwner=String(user.email||'').toLowerCase()==='mopo39999@gmail.com';
  modal(`<p class="eyebrow">ACCOUNT SECURITY</p><h3>Sign-in &amp; recovery</h3><div class="notice"><strong>${escapeHTML(user.email||'')}</strong><br><span class="small">${confirmed?'Email verified':'Email verification pending'}</span></div>${!confirmed?'<button class="secondary wide" id="resendVerificationBtn">Resend verification email</button>':''}<label>New email<input id="newAccountEmail" type="email" autocomplete="email" placeholder="new@example.com"></label><button class="secondary wide" id="changeEmailBtn">Change email</button><hr class="soft"><label>Current password<input id="currentPassword" type="password" autocomplete="current-password"></label><label>New password<input id="newPassword" type="password" minlength="8" autocomplete="new-password"></label><label>Confirm new password<input id="confirmNewPassword" type="password" minlength="8" autocomplete="new-password"></label><button class="secondary wide" id="changePasswordBtn">Change password</button><hr class="soft">${isOwner?(role==='admin'?'<button class="secondary wide" id="openAdminBtn">Open moderation console</button>':'<button class="secondary wide" id="activateOwnerBtn">Activate owner moderation access</button><p class="small">Available only to the verified Paw &amp; Hand owner email.</p>'):''}<hr class="soft"><button class="danger wide" id="signOutAllBtn">Sign out on all devices</button>`,()=>{
    document.getElementById('resendVerificationBtn')?.addEventListener('click',async e=>{setBusy(e.currentTarget,true,'Sending…');const ok=await safe(()=>api.resendVerification(user.email));setBusy(e.currentTarget,false);if(ok)toast('Verification email sent.');});
    document.getElementById('changeEmailBtn').addEventListener('click',async e=>{const email=val('newAccountEmail').trim();if(!email)return toast('Enter a new email address.');setBusy(e.currentTarget,true,'Updating…');const changed=await safe(()=>api.updateEmail(email));setBusy(e.currentTarget,false);if(changed){toast('Email change started. Check your inbox.');closeModal();}});
    document.getElementById('changePasswordBtn').addEventListener('click',async e=>{const current=val('currentPassword'),next=val('newPassword'),confirm=val('confirmNewPassword');if(next.length<8)return toast('New password must be at least 8 characters.');if(next!==confirm)return toast('New passwords do not match.');if(!current)return toast('Enter your current password.');setBusy(e.currentTarget,true,'Updating…');const changed=await safe(()=>api.updatePassword(current,next));setBusy(e.currentTarget,false);if(changed){toast('Password changed.');closeModal();}});
    document.getElementById('activateOwnerBtn')?.addEventListener('click',async e=>{setBusy(e.currentTarget,true,'Activating…');const result=await safe(()=>api.claimOwnerAdmin());setBusy(e.currentTarget,false);if(result){toast('Owner admin access activated.');window.open('https://fnzyffiqbembsvrispzj.supabase.co/functions/v1/paw-hand-admin','_blank','noopener');closeModal();}});
    document.getElementById('openAdminBtn')?.addEventListener('click',()=>window.open('https://fnzyffiqbembsvrispzj.supabase.co/functions/v1/paw-hand-admin','_blank','noopener'));
    document.getElementById('signOutAllBtn').addEventListener('click',async e=>{setBusy(e.currentTarget,true,'Signing out…');const ok=await safe(()=>api.signOutAll());if(ok){closeModal();state={...state,session:null,me:null,profiles:[],matches:[],notifications:[],demo:false};renderLanding();}});
  });
}

function openLegal(kind){
  const privacy=`<p class="eyebrow">PRIVACY</p><h3>Privacy summary</h3><p>Paw &amp; Hand stores the account email through Supabase Auth, your dating profile and dog profile, swipe choices, matches, messages, Dog Date proposals, safety reports, blocks, and profile photos you choose to upload.</p><p>Approximate location labels may be stored, but this MVP does not require precise GPS. Profile photos are stored in a private bucket and shown through expiring signed links.</p><p>We use this data to operate matching, messaging, safety, account access, and requested meetups. Account deletion removes the Auth account and associated app records; profile media is removed first.</p><p class="small">Privacy and support contact: mopo39999@gmail.com. Full Privacy Policy: https://fnzyffiqbembsvrispzj.supabase.co/functions/v1/paw-hand-public/privacy. Legal review and operator details are still required before commercial release.</p>`;
  const rules=`<p class="eyebrow">COMMUNITY</p><h3>Terms &amp; community rules</h3><p><strong>18+ only.</strong> Be truthful about identity, age, relationship intent, and your dog. No harassment, threats, scams, hate, sexual exploitation, impersonation, or solicitation.</p><p>Respect blocks and boundaries. Keep first meetings public, manage dog introductions responsibly, and never treat Paw &amp; Hand compatibility scores as guarantees of safety or behavior.</p><p>Paw &amp; Hand uses baseline automated text filtering plus user reports and blocks. Accounts that create safety risks or abuse the service may be restricted or removed. Reports should be made in good faith.</p><p class="small">Before public launch, replace these starter rules with reviewed Terms of Service and a complete moderation/appeals policy.</p>`;
  modal(kind==='privacy'?privacy:rules);
}

function confirmDeleteAccount(){
  modal(`<p class="eyebrow">DELETE ACCOUNT</p><h3>Permanently delete Paw &amp; Hand?</h3><div class="notice danger-note">This deletes your profile, photos, swipes, matches, messages and other account-linked app data. This cannot be undone.</div><label>Type DELETE to confirm<input id="deleteConfirm" autocomplete="off" placeholder="DELETE"></label><button class="danger wide" id="confirmDeleteBtn">Permanently delete account</button>`,()=>{
    document.getElementById('confirmDeleteBtn').addEventListener('click',async e=>{
      if(val('deleteConfirm').trim()!=='DELETE')return toast('Type DELETE to confirm.');
      const btn=e.currentTarget;setBusy(btn,true,'Deleting…');
      const ok=await safe(()=>api.deleteAccount(),'Could not delete the account.');
      if(!ok){setBusy(btn,false);return;}
      closeModal();if(state.chatCleanup){state.chatCleanup();state.chatCleanup=null;}
      state={...state,session:null,me:null,profiles:[],matches:[],demo:false};renderLanding();toast('Account deleted.');
    });
  });
}

function modal(html,onOpen){document.body.insertAdjacentHTML('beforeend',`<div class="modal-bg" id="modalBg"><div class="modal"><button class="ghost" id="modalX" style="float:right">×</button>${html}</div></div>`);document.getElementById('modalX').addEventListener('click',closeModal);document.getElementById('modalBg').addEventListener('click',e=>{if(e.target.id==='modalBg')closeModal();});onOpen?.();}
function closeModal(){document.getElementById('modalBg')?.remove();}

boot();
