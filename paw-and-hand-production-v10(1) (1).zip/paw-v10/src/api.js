import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY;
const publicSite = (import.meta.env.VITE_PUBLIC_SITE_URL || '').replace(/\/$/,'');
export const cloudConfigured = Boolean(url && key && !url.includes('YOUR-PROJECT'));
export const supabase = cloudConfigured
  ? createClient(url, key, { auth: { persistSession:true, autoRefreshToken:true, detectSessionInUrl:true } })
  : null;

const fail = message => { throw new Error(message); };
const needCloud = () => { if(!supabase) fail('Cloud backend is not configured.'); };
const publicUrl = path => publicSite ? `${publicSite}/${path}` : undefined;

export async function getSession(){
  if(!supabase) return null;
  const { data,error } = await supabase.auth.getSession();
  if(error) fail(error.message);
  return data.session;
}

export async function getCurrentUser(){
  needCloud();
  const { data,error }=await supabase.auth.getUser();
  if(error) fail(error.message);
  return data.user;
}

export async function signUp(email,password){
  needCloud();
  const options=publicUrl('verified')?{emailRedirectTo:publicUrl('verified')}:undefined;
  const { data,error }=await supabase.auth.signUp({email,password,options});
  if(error) fail(error.message);
  return data;
}

export async function resendVerification(email){
  needCloud();
  const options=publicUrl('verified')?{emailRedirectTo:publicUrl('verified')}:undefined;
  const { error }=await supabase.auth.resend({type:'signup',email,options});
  if(error) fail(error.message);
  return true;
}

export async function signIn(email,password){
  needCloud();
  const { data,error }=await supabase.auth.signInWithPassword({email,password});
  if(error) fail(error.message);
  return data;
}

export async function signOut(){
  if(!supabase) return;
  const { error }=await supabase.auth.signOut();
  if(error) fail(error.message);
}

export async function refreshSession(){
  needCloud();
  const { data,error }=await supabase.auth.refreshSession();
  if(error) fail(error.message);
  return data.session;
}

export async function claimOwnerAdmin(){
  needCloud();
  const { data,error }=await supabase.functions.invoke('bootstrap-owner');
  if(error) fail(error.message||'Owner activation failed.');
  if(!data?.ok) fail(data?.error||'Owner activation was not confirmed.');
  await refreshSession();
  return data;
}

export async function signOutAll(){
  needCloud();
  const { error }=await supabase.auth.signOut({scope:'global'});
  if(error) fail(error.message);
  return true;
}

export async function resetPassword(email){
  needCloud();
  const options=publicUrl('reset-password')?{redirectTo:publicUrl('reset-password')}:undefined;
  const { error }=await supabase.auth.resetPasswordForEmail(email,options);
  if(error) fail(error.message);
  return true;
}

export async function updateEmail(email){
  needCloud();
  const options=publicUrl('verified')?{emailRedirectTo:publicUrl('verified')}:undefined;
  const { data,error }=await supabase.auth.updateUser({email},options);
  if(error) fail(error.message);
  return data.user;
}

export async function updatePassword(currentPassword,newPassword){
  needCloud();
  const { data,error }=await supabase.auth.updateUser({password:newPassword,currentPassword});
  if(error) fail(error.message);
  return data.user;
}

export async function getMyProfile(userId){
  needCloud();
  const { data,error }=await supabase.from('profiles').select('*').eq('id',userId).maybeSingle();
  if(error) fail(error.message);
  return data ? await withMedia(data) : null;
}

export async function saveProfile(userId,profile){
  needCloud();
  const row={
    id:userId,
    name:profile.name,
    age:Number(profile.age),
    gender:profile.gender,
    show_me:profile.showMe,
    looking_for:profile.lookingFor,
    bio:profile.bio||'',
    kids:profile.kids,
    smoking:profile.smoking,
    pace:profile.pace,
    activities:profile.activities||[],
    weights:profile.weights||{people:4,dog:5,lifestyle:3},
    dog:profile.dog||{},
    location_label:profile.locationLabel||'',
    completed:true,
    is_visible:profile.isVisible!==false,
    age_min:Number(profile.ageMin??18),
    age_max:Number(profile.ageMax??99),
    preferred_dog_sizes:profile.preferredDogSizes?.length?profile.preferredDogSizes:['Small','Medium','Large','Extra large'],
    preferred_dog_energies:profile.preferredDogEnergies?.length?profile.preferredDogEnergies:['Low','Medium','High'],
    avoid_smokers:Boolean(profile.avoidSmokers),
    require_shared_activity:Boolean(profile.requireSharedActivity),
    last_active_at:new Date().toISOString(),
    updated_at:new Date().toISOString(),
  };
  if(profile.humanPhotoBlob) row.photo_path=await uploadProfileMedia(userId,'human',profile.humanPhotoBlob);
  else if(profile.photoPath) row.photo_path=profile.photoPath;
  if(profile.dogPhotoBlob) row.dog_photo_path=await uploadProfileMedia(userId,'dog',profile.dogPhotoBlob);
  else if(profile.dogPhotoPath) row.dog_photo_path=profile.dogPhotoPath;
  const { data,error }=await supabase.from('profiles').upsert(row).select('*').single();
  if(error) fail(error.message);
  return withMedia(data);
}

export async function touchActive(userId){
  if(!supabase||!userId) return;
  await supabase.from('profiles').update({last_active_at:new Date().toISOString()}).eq('id',userId);
}

async function uploadProfileMedia(userId,kind,blob){
  const path=`${userId}/${kind}.jpg`;
  const { error }=await supabase.storage.from('profile-media').upload(path,blob,{upsert:true,contentType:'image/jpeg',cacheControl:'3600'});
  if(error) fail(error.message);
  return path;
}

async function signedUrl(path){
  if(!path) return null;
  const { data,error }=await supabase.storage.from('profile-media').createSignedUrl(path,3600);
  if(error) return null;
  return data.signedUrl;
}

async function withMedia(row){
  const [humanPhoto,dogPhoto]=await Promise.all([signedUrl(row.photo_path),signedUrl(row.dog_photo_path)]);
  return fromRow(row,humanPhoto,dogPhoto);
}

function fromRow(row,humanPhoto=null,dogPhoto=null){
  return {
    id:row.id,name:row.name,age:row.age,gender:row.gender,showMe:row.show_me,lookingFor:row.looking_for,bio:row.bio,
    kids:row.kids,smoking:row.smoking,pace:row.pace,activities:row.activities||[],weights:row.weights||{people:4,dog:5,lifestyle:3},
    dog:row.dog||{},locationLabel:row.location_label||'',humanPhoto,dogPhoto,photoPath:row.photo_path||null,dogPhotoPath:row.dog_photo_path||null,
    isVisible:row.is_visible!==false,moderationStatus:row.moderation_status||'active',lastActiveAt:row.last_active_at||null,
    ageMin:row.age_min??18,ageMax:row.age_max??99,preferredDogSizes:row.preferred_dog_sizes||['Small','Medium','Large','Extra large'],
    preferredDogEnergies:row.preferred_dog_energies||['Low','Medium','High'],avoidSmokers:Boolean(row.avoid_smokers),requireSharedActivity:Boolean(row.require_shared_activity),distance:null,
  };
}

export async function discoverProfiles(){
  needCloud();
  const { data,error }=await supabase.from('profiles').select('*').order('last_active_at',{ascending:false}).limit(100);
  if(error) fail(error.message);
  return Promise.all((data||[]).map(r=>withMedia(r)));
}

export async function recordSwipe(userId,targetId,action){
  needCloud();
  const { error }=await supabase.from('swipes').upsert({user_id:userId,target_id:targetId,action},{onConflict:'user_id,target_id'});
  if(error) fail(error.message);
  if(action==='pass') return null;
  const matches=await listMatches(userId);
  const match=matches.find(m=>m.other?.id===targetId)||null;
  if(match) requestPush({matchId:match.id}).catch(()=>{});
  return match;
}

export async function listMatches(userId){
  needCloud();
  const { data,error }=await supabase.from('matches').select('*').or(`user_a.eq.${userId},user_b.eq.${userId}`).order('created_at',{ascending:false});
  if(error) fail(error.message);
  const ids=(data||[]).map(m=>m.user_a===userId?m.user_b:m.user_a);
  if(!ids.length) return [];
  const { data:profiles,error:profileError }=await supabase.from('profiles').select('*').in('id',ids);
  if(profileError) fail(profileError.message);
  const profileMap=new Map((await Promise.all((profiles||[]).map(p=>withMedia(p)))).map(p=>[p.id,p]));
  return (data||[]).map(m=>({...m,other:profileMap.get(m.user_a===userId?m.user_b:m.user_a)})).filter(x=>x.other);
}

export async function listMessages(matchId){
  needCloud();
  const { data,error }=await supabase.from('messages').select('*').eq('match_id',matchId).order('created_at',{ascending:true});
  if(error) fail(error.message);
  return data||[];
}

export async function sendMessage(matchId,senderId,body,kind='text',metadata={}){
  needCloud();
  const clean=String(body||'').trim().slice(0,1000);
  if(!clean) fail('Message cannot be empty.');
  const { data,error }=await supabase.from('messages').insert({match_id:matchId,sender_id:senderId,body:clean,kind,metadata}).select('*').single();
  if(error) fail(error.message);
  requestPush({messageId:data.id}).catch(()=>{});
  return data;
}

export function subscribeToMessages(matchId,onMessage){
  if(!supabase) return ()=>{};
  const channel=supabase.channel(`match-${matchId}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`match_id=eq.${matchId}`},payload=>onMessage(payload.new)).subscribe();
  return ()=>supabase.removeChannel(channel);
}

export async function proposeDogDate(matchId,userId,{place,dateTime,note}){
  needCloud();
  const { data,error }=await supabase.from('date_proposals').insert({match_id:matchId,proposed_by:userId,place_name:place,proposed_for:dateTime?new Date(dateTime).toISOString():null,note:note||''}).select('*').single();
  if(error) fail(error.message);
  const when=dateTime?` on ${new Date(dateTime).toLocaleString()}`:'';
  await sendMessage(matchId,userId,`🐾 Dog Date idea: ${place}${when}. ${note||'Want to meet there with the dogs?'}`,'dog_date',{proposal_id:data.id});
  return data;
}

export async function blockUser(userId,blockedUserId){
  needCloud();
  const { error }=await supabase.from('blocks').upsert({user_id:userId,blocked_user_id:blockedUserId},{onConflict:'user_id,blocked_user_id'});
  if(error) fail(error.message);
}

export async function reportUser(userId,reportedUserId,reason,details='',context={}){
  needCloud();
  const row={reporter_id:userId,reported_user_id:reportedUserId,reason,details:String(details).slice(0,1000)};
  if(context.matchId) row.match_id=context.matchId;
  if(context.messageId) row.message_id=context.messageId;
  const { error }=await supabase.from('reports').insert(row);
  if(error) fail(error.message);
  return true;
}

export async function setProfileVisibility(userId,visible){
  needCloud();
  const { data,error }=await supabase.from('profiles').update({is_visible:Boolean(visible),updated_at:new Date().toISOString()}).eq('id',userId).select('is_visible').single();
  if(error) fail(error.message);
  return data.is_visible;
}

export async function listNotifications(limit=50){
  needCloud();
  const { data,error }=await supabase.from('notifications').select('*').order('created_at',{ascending:false}).limit(limit);
  if(error) fail(error.message);
  return data||[];
}

export async function markNotificationsRead(ids=[]){
  needCloud();
  if(!ids.length) return true;
  const { error }=await supabase.from('notifications').update({read_at:new Date().toISOString()}).in('id',ids);
  if(error) fail(error.message);
  return true;
}

export function subscribeToNotifications(userId,onNotification){
  if(!supabase) return ()=>{};
  const channel=supabase.channel(`notifications-${userId}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${userId}`},payload=>onNotification(payload.new)).subscribe();
  return ()=>supabase.removeChannel(channel);
}

export async function getNotificationPreferences(userId){
  needCloud();
  const { data,error }=await supabase.from('notification_preferences').select('*').eq('user_id',userId).maybeSingle();
  if(error) fail(error.message);
  return data||{user_id:userId,new_matches:true,messages:true,dog_dates:true,safety:true};
}

export async function saveNotificationPreferences(userId,prefs){
  needCloud();
  const row={user_id:userId,new_matches:Boolean(prefs.new_matches),messages:Boolean(prefs.messages),dog_dates:Boolean(prefs.dog_dates),safety:Boolean(prefs.safety),updated_at:new Date().toISOString()};
  const { data,error }=await supabase.from('notification_preferences').upsert(row).select('*').single();
  if(error) fail(error.message);
  return data;
}

export async function registerPushDevice(userId,token,platform){
  needCloud();
  const { data,error }=await supabase.from('push_devices').upsert({user_id:userId,token,platform,enabled:true,updated_at:new Date().toISOString()},{onConflict:'user_id,token'}).select('id,platform,enabled').single();
  if(error) fail(error.message);
  return data;
}

export async function listPushDevices(){
  needCloud();
  const { data,error }=await supabase.from('push_devices').select('id,platform,enabled,last_success_at,last_error,created_at,updated_at').order('updated_at',{ascending:false});
  if(error) fail(error.message);
  return data||[];
}

export async function disablePushDevice(id){
  needCloud();
  const { error }=await supabase.from('push_devices').update({enabled:false,updated_at:new Date().toISOString()}).eq('id',id);
  if(error) fail(error.message);
  return true;
}

export async function requestPush(payload){
  if(!supabase) return null;
  const { data,error }=await supabase.functions.invoke('send-push',{body:payload});
  if(error) return null;
  return data;
}

export async function deleteAccount(){
  needCloud();
  const { data,error }=await supabase.functions.invoke('delete-account');
  if(error) fail(error.message||'Account deletion failed.');
  if(!data?.deleted) fail(data?.error||'Account deletion was not confirmed.');
  try{await supabase.auth.signOut({scope:'local'});}catch{}
  return true;
}

export function onAuthChange(callback){
  if(!supabase) return ()=>{};
  const { data }=supabase.auth.onAuthStateChange((_event,session)=>callback(session));
  return ()=>data.subscription.unsubscribe();
}
