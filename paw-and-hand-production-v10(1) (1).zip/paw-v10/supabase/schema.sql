-- Paw & Hand production backend
-- This is the deployment schema currently applied to the connected Supabase project.

create extension if not exists pgcrypto;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 30),
  age int not null check (age between 18 and 99),
  gender text not null check (gender in ('Man','Woman','Nonbinary')),
  show_me text not null default 'Everyone' check (show_me in ('Women','Men','Everyone')),
  looking_for text not null,
  bio text not null default '' check (char_length(bio) <= 300),
  kids text not null default 'No preference',
  smoking text not null default 'No preference',
  pace text not null default 'Balanced',
  activities text[] not null default '{}',
  weights jsonb not null default '{"people":4,"dog":5,"lifestyle":3}'::jsonb,
  dog jsonb not null default '{}'::jsonb,
  location_label text not null default '' check (char_length(location_label) <= 60),
  photo_path text,
  dog_photo_path text,
  completed boolean not null default false,
  is_visible boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.swipes (
  user_id uuid not null references auth.users(id) on delete cascade,
  target_id uuid not null references auth.users(id) on delete cascade,
  action text not null check (action in ('pass','like','paw_like')),
  created_at timestamptz not null default now(),
  primary key (user_id,target_id),
  check (user_id <> target_id)
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references auth.users(id) on delete cascade,
  user_b uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (user_a <> user_b)
);
create unique index if not exists matches_pair_unique on public.matches (least(user_a,user_b), greatest(user_a,user_b));
create index if not exists matches_user_a_idx on public.matches(user_a);
create index if not exists matches_user_b_idx on public.matches(user_b);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  kind text not null default 'text' check (kind in ('text','dog_date','system')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.date_proposals (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  proposed_by uuid not null references auth.users(id) on delete cascade,
  place_name text not null check (char_length(place_name) between 1 and 120),
  proposed_for timestamptz,
  note text not null default '' check (char_length(note) <= 300),
  status text not null default 'proposed' check (status in ('proposed','accepted','declined','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.blocks (
  user_id uuid not null references auth.users(id) on delete cascade,
  blocked_user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id,blocked_user_id),
  check (user_id <> blocked_user_id)
);

create table if not exists public.reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  details text not null default '' check (char_length(details) <= 1000),
  created_at timestamptz not null default now()
);

create index if not exists swipes_target_idx on public.swipes(target_id);
create index if not exists messages_match_idx on public.messages(match_id);
create index if not exists messages_sender_idx on public.messages(sender_id);
create index if not exists date_proposals_match_idx on public.date_proposals(match_id);
create index if not exists date_proposals_proposed_by_idx on public.date_proposals(proposed_by);
create index if not exists blocks_blocked_user_idx on public.blocks(blocked_user_id);
create index if not exists reports_reporter_idx on public.reports(reporter_id);
create index if not exists reports_reported_user_idx on public.reports(reported_user_id);

create or replace function private.is_blocked_pair(a uuid,b uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.blocks where (user_id=a and blocked_user_id=b) or (user_id=b and blocked_user_id=a));
$$;

create or replace function private.is_matched_with(target uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from public.matches m
    where ((m.user_a=auth.uid() and m.user_b=target) or (m.user_b=auth.uid() and m.user_a=target))
      and not private.is_blocked_pair(auth.uid(),target)
  );
$$;

create or replace function private.can_access_match(target_match uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from public.matches m
    where m.id=target_match
      and (m.user_a=auth.uid() or m.user_b=auth.uid())
      and not private.is_blocked_pair(m.user_a,m.user_b)
  );
$$;

revoke all on function private.is_blocked_pair(uuid,uuid) from public, anon;
revoke all on function private.is_matched_with(uuid) from public, anon;
revoke all on function private.can_access_match(uuid) from public, anon;
grant execute on function private.is_blocked_pair(uuid,uuid), private.is_matched_with(uuid), private.can_access_match(uuid) to authenticated;

create or replace function private.create_match_after_swipe()
returns trigger language plpgsql security definer set search_path=public as $$
declare
  reciprocal boolean;
  a uuid;
  b uuid;
begin
  if new.action not in ('like','paw_like') then return new; end if;
  select exists(
    select 1 from public.swipes
    where user_id=new.target_id and target_id=new.user_id and action in ('like','paw_like')
  ) into reciprocal;
  if reciprocal and not private.is_blocked_pair(new.user_id,new.target_id) then
    if new.user_id::text < new.target_id::text then a:=new.user_id; b:=new.target_id; else a:=new.target_id; b:=new.user_id; end if;
    insert into public.matches(user_a,user_b) values(a,b) on conflict do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_create_match_after_swipe on public.swipes;
create trigger trg_create_match_after_swipe after insert or update of action on public.swipes for each row execute function private.create_match_after_swipe();
revoke all on function private.create_match_after_swipe() from public, anon, authenticated;

grant select, insert, update, delete on public.profiles, public.swipes, public.matches, public.messages, public.date_proposals, public.blocks, public.reports to authenticated;
grant usage, select on sequence public.reports_id_seq to authenticated;

alter table public.profiles enable row level security;
alter table public.swipes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.date_proposals enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (
  id=(select auth.uid())
  or private.is_matched_with(id)
  or (
    completed=true and is_visible=true and id<>(select auth.uid())
    and not private.is_blocked_pair((select auth.uid()),id)
    and not exists(select 1 from public.swipes s where s.user_id=(select auth.uid()) and s.target_id=profiles.id)
    and (
      (select show_me from public.profiles where id=(select auth.uid()))='Everyone'
      or ((select show_me from public.profiles where id=(select auth.uid()))='Women' and gender='Woman')
      or ((select show_me from public.profiles where id=(select auth.uid()))='Men' and gender='Man')
    )
  )
);
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert to authenticated with check (id=(select auth.uid()));
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated using (id=(select auth.uid())) with check (id=(select auth.uid()));

drop policy if exists swipes_all_own on public.swipes;
create policy swipes_all_own on public.swipes for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

drop policy if exists matches_read on public.matches;
create policy matches_read on public.matches for select to authenticated using ((user_a=(select auth.uid()) or user_b=(select auth.uid())) and not private.is_blocked_pair(user_a,user_b));

drop policy if exists messages_read on public.messages;
create policy messages_read on public.messages for select to authenticated using (private.can_access_match(match_id));
drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert to authenticated with check (sender_id=(select auth.uid()) and private.can_access_match(match_id));
drop policy if exists dates_read on public.date_proposals;
create policy dates_read on public.date_proposals for select to authenticated using (private.can_access_match(match_id));
drop policy if exists dates_insert on public.date_proposals;
create policy dates_insert on public.date_proposals for insert to authenticated with check (proposed_by=(select auth.uid()) and private.can_access_match(match_id));
drop policy if exists dates_update on public.date_proposals;
create policy dates_update on public.date_proposals for update to authenticated using (private.can_access_match(match_id)) with check (private.can_access_match(match_id));

drop policy if exists blocks_own on public.blocks;
create policy blocks_own on public.blocks for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert to authenticated with check (reporter_id=(select auth.uid()));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('profile-media','profile-media',false,3145728,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=false,file_size_limit=3145728,allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists profile_media_read on storage.objects;
create policy profile_media_read on storage.objects for select to authenticated using (bucket_id='profile-media');
drop policy if exists profile_media_insert on storage.objects;
create policy profile_media_insert on storage.objects for insert to authenticated with check (bucket_id='profile-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists profile_media_update on storage.objects;
create policy profile_media_update on storage.objects for update to authenticated using (bucket_id='profile-media' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='profile-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists profile_media_delete on storage.objects;
create policy profile_media_delete on storage.objects for delete to authenticated using (bucket_id='profile-media' and (storage.foldername(name))[1]=auth.uid()::text);

do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;

-- v5 hardening: avoid self-recursive profile RLS, tighten media reads, and use least privilege.
create or replace function private.my_show_me()
returns text
language sql
stable
security definer
set search_path=public
as $$
  select show_me from public.profiles where id=(select auth.uid());
$$;
revoke all on function private.my_show_me() from public, anon;
grant execute on function private.my_show_me() to authenticated;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (
  id=(select auth.uid())
  or private.is_matched_with(id)
  or (
    completed=true and is_visible=true and id<>(select auth.uid())
    and not private.is_blocked_pair((select auth.uid()),id)
    and not exists(select 1 from public.swipes s where s.user_id=(select auth.uid()) and s.target_id=profiles.id)
    and (
      private.my_show_me()='Everyone'
      or (private.my_show_me()='Women' and gender='Woman')
      or (private.my_show_me()='Men' and gender='Man')
    )
  )
);

drop policy if exists profile_media_read on storage.objects;
create policy profile_media_read on storage.objects for select to authenticated using (
  bucket_id='profile-media'
  and exists (
    select 1 from public.profiles p
    where p.id::text=(storage.foldername(name))[1]
  )
);

revoke all on public.profiles, public.swipes, public.matches, public.messages, public.date_proposals, public.blocks, public.reports from authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.swipes to authenticated;
grant select on public.matches to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert on public.date_proposals to authenticated;
grant update(status) on public.date_proposals to authenticated;
grant select, insert, update, delete on public.blocks to authenticated;
grant insert on public.reports to authenticated;
grant usage, select on sequence public.reports_id_seq to authenticated;

-- v6 safety + moderation hardening.
-- Baseline server-side text filtering, message/report rate limits, and report context.
alter table public.reports add column if not exists match_id uuid references public.matches(id) on delete set null;
alter table public.reports add column if not exists message_id uuid references public.messages(id) on delete set null;
alter table public.reports add column if not exists status text not null default 'pending' check (status in ('pending','reviewing','resolved','dismissed'));
create index if not exists reports_match_idx on public.reports(match_id);
create index if not exists reports_message_idx on public.reports(message_id);

create table if not exists private.moderation_terms (
  pattern text primary key,
  category text not null,
  active boolean not null default true
);
revoke all on private.moderation_terms from public, anon, authenticated;

insert into private.moderation_terms(pattern,category) values
  ('child porn','sexual exploitation'),
  ('underage sex','sexual exploitation'),
  ('rape fantasy','sexual violence'),
  ('kill yourself','threats/self-harm harassment'),
  ('i will kill you','violent threat'),
  ('i''m going to kill you','violent threat'),
  ('send nudes','sexual solicitation'),
  ('pay me for sex','commercial sexual solicitation'),
  ('escort services','commercial sexual solicitation')
on conflict (pattern) do update set category=excluded.category, active=true;

create or replace function private.text_is_allowed(input_text text)
returns boolean language sql stable security definer set search_path=private,public as $$
  select not exists (
    select 1 from private.moderation_terms t
    where t.active and strpos(lower(coalesce(input_text,'')), lower(t.pattern)) > 0
  );
$$;
revoke all on function private.text_is_allowed(text) from public, anon, authenticated;

create or replace function private.enforce_profile_content()
returns trigger language plpgsql security definer set search_path=private,public as $$
begin
  if not private.text_is_allowed(new.name)
     or not private.text_is_allowed(new.bio)
     or not private.text_is_allowed(new.location_label)
     or not private.text_is_allowed(new.dog->>'name')
     or not private.text_is_allowed(new.dog->>'breed') then
    raise exception using errcode='P0001', message='Profile text violates Paw & Hand community rules.';
  end if;
  return new;
end;
$$;
revoke all on function private.enforce_profile_content() from public, anon, authenticated;
drop trigger if exists trg_profile_content_moderation on public.profiles;
create trigger trg_profile_content_moderation before insert or update of name,bio,location_label,dog on public.profiles
for each row execute function private.enforce_profile_content();

create or replace function private.enforce_message_safety()
returns trigger language plpgsql security definer set search_path=private,public as $$
declare recent_count int;
begin
  if not private.text_is_allowed(new.body) then
    raise exception using errcode='P0001', message='Message violates Paw & Hand community rules.';
  end if;
  select count(*) into recent_count from public.messages
  where sender_id=new.sender_id and created_at > now() - interval '1 minute';
  if recent_count >= 30 then
    raise exception using errcode='P0001', message='You are sending messages too quickly. Try again shortly.';
  end if;
  return new;
end;
$$;
revoke all on function private.enforce_message_safety() from public, anon, authenticated;
drop trigger if exists trg_message_safety on public.messages;
create trigger trg_message_safety before insert on public.messages
for each row execute function private.enforce_message_safety();

create or replace function private.enforce_date_content()
returns trigger language plpgsql security definer set search_path=private,public as $$
begin
  if not private.text_is_allowed(new.place_name) or not private.text_is_allowed(new.note) then
    raise exception using errcode='P0001', message='Dog Date text violates Paw & Hand community rules.';
  end if;
  return new;
end;
$$;
revoke all on function private.enforce_date_content() from public, anon, authenticated;
drop trigger if exists trg_date_content_moderation on public.date_proposals;
create trigger trg_date_content_moderation before insert or update of place_name,note on public.date_proposals
for each row execute function private.enforce_date_content();

create or replace function private.enforce_report_rate_limit()
returns trigger language plpgsql security definer set search_path=public as $$
declare recent_count int;
begin
  select count(*) into recent_count from public.reports
  where reporter_id=new.reporter_id and created_at > now() - interval '1 hour';
  if recent_count >= 10 then
    raise exception using errcode='P0001', message='Too many reports submitted. Try again later.';
  end if;
  return new;
end;
$$;
revoke all on function private.enforce_report_rate_limit() from public, anon, authenticated;
drop trigger if exists trg_report_rate_limit on public.reports;
create trigger trg_report_rate_limit before insert on public.reports
for each row execute function private.enforce_report_rate_limit();

-- v6 report-context authorization hardening.
drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports
for insert to authenticated
with check (
  reporter_id=(select auth.uid())
  and reported_user_id<>(select auth.uid())
  and (
    match_id is null
    or (
      private.can_access_match(match_id)
      and exists (
        select 1 from public.matches mt
        where mt.id=reports.match_id
          and (mt.user_a=reports.reported_user_id or mt.user_b=reports.reported_user_id)
      )
    )
  )
  and (
    message_id is null
    or exists (
      select 1 from public.messages msg
      where msg.id=reports.message_id
        and private.can_access_match(msg.match_id)
        and (reports.match_id is null or msg.match_id=reports.match_id)
    )
  )
);


-- BEGIN PAW & HAND V9 PRODUCT LAYER
-- Paw & Hand v9: stronger reciprocal matching, moderation state, notifications, and push device registration.

alter table public.profiles add column if not exists age_min int not null default 18;
alter table public.profiles add column if not exists age_max int not null default 99;
alter table public.profiles add column if not exists preferred_dog_sizes text[] not null default array['Small','Medium','Large','Extra large']::text[];
alter table public.profiles add column if not exists preferred_dog_energies text[] not null default array['Low','Medium','High']::text[];
alter table public.profiles add column if not exists avoid_smokers boolean not null default false;
alter table public.profiles add column if not exists require_shared_activity boolean not null default false;
alter table public.profiles add column if not exists moderation_status text not null default 'active';
alter table public.profiles add column if not exists last_active_at timestamptz not null default now();

do $$ begin
  alter table public.profiles add constraint profiles_age_range_check check (age_min between 18 and 99 and age_max between 18 and 99 and age_min <= age_max);
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_moderation_status_check check (moderation_status in ('active','suspended','banned'));
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_preferred_dog_sizes_check check (preferred_dog_sizes <@ array['Small','Medium','Large','Extra large']::text[] and cardinality(preferred_dog_sizes) > 0);
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_preferred_dog_energies_check check (preferred_dog_energies <@ array['Low','Medium','High']::text[] and cardinality(preferred_dog_energies) > 0);
exception when duplicate_object then null; end $$;

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('match','message','dog_date','safety','account')),
  title text not null check (char_length(title) between 1 and 120),
  body text not null default '' check (char_length(body) <= 300),
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists notifications_user_unread_idx on public.notifications(user_id, created_at desc) where read_at is null;

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  new_matches boolean not null default true,
  messages boolean not null default true,
  dog_dates boolean not null default true,
  safety boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.push_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null check (platform in ('android','ios')),
  token text not null check (char_length(token) between 16 and 4096),
  enabled boolean not null default true,
  last_success_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, token)
);
create index if not exists push_devices_user_idx on public.push_devices(user_id) where enabled=true;

alter table public.reports add column if not exists severity text not null default 'normal';
alter table public.reports add column if not exists admin_note text not null default '';
alter table public.reports add column if not exists reviewed_at timestamptz;
alter table public.reports add column if not exists reviewed_by uuid references auth.users(id) on delete set null;
do $$ begin
  alter table public.reports add constraint reports_severity_check check (severity in ('normal','urgent','critical'));
exception when duplicate_object then null; end $$;

create table if not exists public.moderation_actions (
  id bigint generated always as identity primary key,
  admin_user_id uuid references auth.users(id) on delete set null,
  target_user_id uuid references auth.users(id) on delete set null,
  report_id bigint references public.reports(id) on delete set null,
  action text not null check (action in ('note','warn','suspend','ban','restore','dismiss','resolve')),
  note text not null default '' check (char_length(note) <= 2000),
  created_at timestamptz not null default now()
);
create index if not exists moderation_actions_target_idx on public.moderation_actions(target_user_id,created_at desc);
create index if not exists moderation_actions_report_idx on public.moderation_actions(report_id);

create or replace function private.my_match_settings()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'age', age,
    'gender', gender,
    'show_me', show_me,
    'smoking', smoking,
    'dog_size', coalesce(dog->>'size',''),
    'dog_energy', coalesce(dog->>'energy',''),
    'age_min', age_min,
    'age_max', age_max,
    'preferred_dog_sizes', to_jsonb(preferred_dog_sizes),
    'preferred_dog_energies', to_jsonb(preferred_dog_energies),
    'avoid_smokers', avoid_smokers,
    'require_shared_activity', require_shared_activity,
    'moderation_status', moderation_status
  )
  from public.profiles
  where id=(select auth.uid());
$$;

create or replace function private.my_activities()
returns text[]
language sql
stable
security definer
set search_path=public
as $$
  select activities from public.profiles where id=(select auth.uid());
$$;

revoke all on function private.my_match_settings() from public, anon;
revoke all on function private.my_activities() from public, anon;
grant execute on function private.my_match_settings(), private.my_activities() to authenticated;

create or replace function private.is_matched_with(target uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.matches m
    join public.profiles me on me.id=(select auth.uid())
    join public.profiles other_p on other_p.id=target
    where ((m.user_a=(select auth.uid()) and m.user_b=target) or (m.user_b=(select auth.uid()) and m.user_a=target))
      and me.moderation_status='active'
      and other_p.moderation_status='active'
      and not private.is_blocked_pair((select auth.uid()),target)
  );
$$;

create or replace function private.can_access_match(target_match uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.matches m
    join public.profiles a on a.id=m.user_a
    join public.profiles b on b.id=m.user_b
    where m.id=target_match
      and (m.user_a=(select auth.uid()) or m.user_b=(select auth.uid()))
      and a.moderation_status='active'
      and b.moderation_status='active'
      and not private.is_blocked_pair(m.user_a,m.user_b)
  );
$$;

create or replace function private.create_match_after_swipe()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  reciprocal boolean;
  a uuid;
  b uuid;
  both_active boolean;
begin
  if new.action not in ('like','paw_like') then return new; end if;
  select exists(
    select 1 from public.swipes
    where user_id=new.target_id and target_id=new.user_id and action in ('like','paw_like')
  ) into reciprocal;
  select count(*)=2 into both_active from public.profiles p where p.id in (new.user_id,new.target_id) and p.moderation_status='active';
  if reciprocal and both_active and not private.is_blocked_pair(new.user_id,new.target_id) then
    if new.user_id::text < new.target_id::text then a:=new.user_id; b:=new.target_id; else a:=new.target_id; b:=new.user_id; end if;
    insert into public.matches(user_a,user_b) values(a,b) on conflict do nothing;
  end if;
  return new;
end;
$$;
revoke all on function private.create_match_after_swipe() from public, anon, authenticated;

-- Reciprocal discovery: both people must satisfy one another's age/gender/smoking/dog preferences.
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (
  id=(select auth.uid())
  or private.is_matched_with(id)
  or (
    completed=true
    and is_visible=true
    and moderation_status='active'
    and id<>(select auth.uid())
    and (private.my_match_settings()->>'moderation_status')='active'
    and not private.is_blocked_pair((select auth.uid()),id)
    and not exists(select 1 from public.swipes s where s.user_id=(select auth.uid()) and s.target_id=profiles.id)
    and (
      (private.my_match_settings()->>'show_me')='Everyone'
      or ((private.my_match_settings()->>'show_me')='Women' and gender='Woman')
      or ((private.my_match_settings()->>'show_me')='Men' and gender='Man')
    )
    and (
      show_me='Everyone'
      or (show_me='Women' and (private.my_match_settings()->>'gender')='Woman')
      or (show_me='Men' and (private.my_match_settings()->>'gender')='Man')
    )
    and age between (private.my_match_settings()->>'age_min')::int and (private.my_match_settings()->>'age_max')::int
    and (private.my_match_settings()->>'age')::int between age_min and age_max
    and (not (private.my_match_settings()->>'avoid_smokers')::boolean or smoking<>'Smoker')
    and (not avoid_smokers or (private.my_match_settings()->>'smoking')<>'Smoker')
    and ((private.my_match_settings()->'preferred_dog_sizes') ? coalesce(dog->>'size',''))
    and ((private.my_match_settings()->>'dog_size') = any(preferred_dog_sizes))
    and ((private.my_match_settings()->'preferred_dog_energies') ? coalesce(dog->>'energy',''))
    and ((private.my_match_settings()->>'dog_energy') = any(preferred_dog_energies))
    and (
      (not (private.my_match_settings()->>'require_shared_activity')::boolean and not require_shared_activity)
      or activities && private.my_activities()
    )
  )
);

-- Prevent a suspended/banned user from reactivating themselves through the client.
revoke update on public.profiles from authenticated;
grant update(id,name,age,gender,show_me,looking_for,bio,kids,smoking,pace,activities,weights,dog,location_label,photo_path,dog_photo_path,completed,is_visible,updated_at,age_min,age_max,preferred_dog_sizes,preferred_dog_energies,avoid_smokers,require_shared_activity,last_active_at)
  on public.profiles to authenticated;

-- Reports are write-only from the client; moderation fields remain server/admin only.
revoke all on public.reports from authenticated;
grant insert(reporter_id,reported_user_id,reason,details,match_id,message_id) on public.reports to authenticated;
grant usage, select on sequence public.reports_id_seq to authenticated;

alter table public.notifications enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.push_devices enable row level security;
alter table public.moderation_actions enable row level security;

revoke all on public.notifications, public.notification_preferences, public.push_devices, public.moderation_actions from anon, authenticated;
grant select, update, delete on public.notifications to authenticated;
grant select, insert, update, delete on public.notification_preferences to authenticated;
grant select, insert, update, delete on public.push_devices to authenticated;

create policy notifications_read_own on public.notifications for select to authenticated using (user_id=(select auth.uid()));
create policy notifications_update_own on public.notifications for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy notifications_delete_own on public.notifications for delete to authenticated using (user_id=(select auth.uid()));

create policy notification_preferences_own on public.notification_preferences for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy push_devices_own on public.push_devices for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

create or replace function private.notify_new_match()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  name_a text;
  name_b text;
begin
  select name into name_a from public.profiles where id=new.user_a;
  select name into name_b from public.profiles where id=new.user_b;
  insert into public.notifications(user_id,kind,title,body,data) values
    (new.user_a,'match','It''s a match!',coalesce(name_b,'Someone')||' liked you too.',jsonb_build_object('match_id',new.id,'other_user_id',new.user_b)),
    (new.user_b,'match','It''s a match!',coalesce(name_a,'Someone')||' liked you too.',jsonb_build_object('match_id',new.id,'other_user_id',new.user_a));
  return new;
end;
$$;

drop trigger if exists trg_notify_new_match on public.matches;
create trigger trg_notify_new_match after insert on public.matches for each row execute function private.notify_new_match();
revoke all on function private.notify_new_match() from public, anon, authenticated;

create or replace function private.notify_new_message()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  target_user uuid;
  sender_name text;
  notification_kind text;
  notification_title text;
  notification_body text;
begin
  if new.kind='system' then return new; end if;
  select case when m.user_a=new.sender_id then m.user_b else m.user_a end into target_user
  from public.matches m where m.id=new.match_id and (m.user_a=new.sender_id or m.user_b=new.sender_id);
  if target_user is null then return new; end if;
  select name into sender_name from public.profiles where id=new.sender_id;
  notification_kind := case when new.kind='dog_date' then 'dog_date' else 'message' end;
  notification_title := case when new.kind='dog_date' then 'New Dog Date idea' else 'New message' end;
  notification_body := coalesce(sender_name,'A match') || case when new.kind='dog_date' then ' suggested a Dog Date.' else ' sent you a message.' end;
  insert into public.notifications(user_id,kind,title,body,data)
  values(target_user,notification_kind,notification_title,notification_body,jsonb_build_object('match_id',new.match_id,'message_id',new.id,'sender_id',new.sender_id));
  return new;
end;
$$;

drop trigger if exists trg_notify_new_message on public.messages;
create trigger trg_notify_new_message after insert on public.messages for each row execute function private.notify_new_message();
revoke all on function private.notify_new_message() from public, anon, authenticated;

do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;

-- END PAW & HAND V9 PRODUCT LAYER

-- v9 push delivery state
alter table public.notifications add column if not exists push_sent_at timestamptz;

-- BEGIN PAW & HAND V9 REPORT TRIAGE
create or replace function private.classify_report_severity()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  new.severity := case
    when new.reason in ('Underage concern','Sexual exploitation','Threats or violence') then 'critical'
    when new.reason in ('Hate or discrimination','Unsafe behavior','Harassment') then 'urgent'
    else 'normal'
  end;
  return new;
end;
$$;
drop trigger if exists trg_report_severity_triage on public.reports;
create trigger trg_report_severity_triage before insert or update of reason on public.reports for each row execute function private.classify_report_severity();
revoke all on function private.classify_report_severity() from public, anon, authenticated;

-- END PAW & HAND V9 REPORT TRIAGE

-- BEGIN PAW & HAND V9 MODERATION HARDENING
drop policy if exists moderation_actions_deny_client on public.moderation_actions;
create policy moderation_actions_deny_client on public.moderation_actions for select to authenticated using (false);
create index if not exists moderation_actions_admin_user_idx on public.moderation_actions(admin_user_id);
create index if not exists reports_reviewed_by_idx on public.reports(reviewed_by);

-- END PAW & HAND V9 MODERATION HARDENING
-- v9 notification least-privilege update grant
revoke update on public.notifications from authenticated;
grant update(read_at) on public.notifications to authenticated;


-- BEGIN PAW & HAND V10 DATA-API GRANT HARDENING
-- Signed-out clients do not need direct access to dating data.
revoke all privileges on table public.blocks from anon;
revoke all privileges on table public.date_proposals from anon;
revoke all privileges on table public.matches from anon;
revoke all privileges on table public.messages from anon;
revoke all privileges on table public.profiles from anon;
revoke all privileges on table public.reports from anon;
revoke all privileges on table public.swipes from anon;

-- Keep client writes aligned to the columns the app actually changes.
revoke update on public.profiles from authenticated;
grant update(id,name,age,gender,show_me,looking_for,bio,kids,smoking,pace,activities,weights,dog,location_label,photo_path,dog_photo_path,completed,is_visible,updated_at,age_min,age_max,preferred_dog_sizes,preferred_dog_energies,avoid_smokers,require_shared_activity,last_active_at)
  on public.profiles to authenticated;
revoke update on public.date_proposals from authenticated;
grant update(status) on public.date_proposals to authenticated;
revoke update on public.notifications from authenticated;
grant update(read_at) on public.notifications to authenticated;
grant insert on public.reports to authenticated;
-- END PAW & HAND V10 DATA-API GRANT HARDENING
