import { withSupabase } from 'npm:@supabase/server@1.4.1'

type AdminRole = 'admin' | 'moderator'
const allowedRoles = new Set<AdminRole>(['admin','moderator'])

const json = (body: unknown, status = 200) => Response.json(body, { status })

export default {
  fetch: withSupabase({ auth: 'user' }, async (req, ctx) => {
    const userId = ctx.userClaims?.id ?? ctx.userClaims?.sub
    if (!userId) return json({ error: 'Authenticated user not found.' }, 401)

    const { data: authUser, error: authError } = await ctx.supabaseAdmin.auth.admin.getUserById(userId)
    if (authError || !authUser?.user) return json({ error: 'Could not verify moderator account.' }, 401)
    const role = authUser.user.app_metadata?.role as AdminRole | undefined
    if (!role || !allowedRoles.has(role)) return json({ error: 'Moderator access required.' }, 403)

    const payload = req.method === 'POST' ? await req.json().catch(() => ({})) : {}
    const action = String(payload?.action || 'dashboard')

    if (action === 'dashboard') {
      const since24h=new Date(Date.now()-24*60*60*1000).toISOString()
      const [{ count: totalUsers }, { count: pendingReports }, { count: suspendedUsers }, { count: bannedUsers }, { count: reports24h }, reportResult] = await Promise.all([
        ctx.supabaseAdmin.from('profiles').select('*', { count:'exact', head:true }),
        ctx.supabaseAdmin.from('reports').select('*', { count:'exact', head:true }).in('status',['pending','reviewing']),
        ctx.supabaseAdmin.from('profiles').select('*', { count:'exact', head:true }).eq('moderation_status','suspended'),
        ctx.supabaseAdmin.from('profiles').select('*', { count:'exact', head:true }).eq('moderation_status','banned'),
        ctx.supabaseAdmin.from('reports').select('*', { count:'exact', head:true }).gte('created_at',since24h),
        ctx.supabaseAdmin.from('reports').select('id,reporter_id,reported_user_id,reason,details,created_at,match_id,message_id,status,severity,admin_note,reviewed_at,reviewed_by').order('created_at',{ascending:false}).limit(100),
      ])
      if (reportResult.error) return json({ error: reportResult.error.message }, 500)
      const reports = reportResult.data ?? []
      const userIds = [...new Set(reports.flatMap((r:any)=>[r.reporter_id,r.reported_user_id]).filter(Boolean))]
      const messageIds = [...new Set(reports.map((r:any)=>r.message_id).filter(Boolean))]
      const profilesResult = userIds.length
        ? await ctx.supabaseAdmin.from('profiles').select('id,name,age,moderation_status,is_visible,location_label,dog').in('id',userIds)
        : { data:[], error:null }
      if (profilesResult.error) return json({ error: profilesResult.error.message }, 500)
      const messagesResult = messageIds.length
        ? await ctx.supabaseAdmin.from('messages').select('id,body,kind,created_at,sender_id,match_id').in('id',messageIds)
        : { data:[], error:null }
      if (messagesResult.error) return json({ error: messagesResult.error.message }, 500)
      const profileMap = Object.fromEntries((profilesResult.data ?? []).map((p:any)=>[p.id,p]))
      const messageMap = Object.fromEntries((messagesResult.data ?? []).map((m:any)=>[m.id,m]))
      return json({
        role,
        stats:{ totalUsers: totalUsers ?? 0, pendingReports: pendingReports ?? 0, reports24h: reports24h ?? 0, suspendedUsers: suspendedUsers ?? 0, bannedUsers: bannedUsers ?? 0 },
        reports: reports.map((r:any)=>({ ...r, reporter:profileMap[r.reporter_id] ?? null, reported:profileMap[r.reported_user_id] ?? null, message:r.message_id?messageMap[r.message_id]??null:null })),
      })
    }

    if (action === 'search_users') {
      const term=String(payload?.query||'').trim().slice(0,80)
      if(term.length<2) return json({ users:[] })
      let query=ctx.supabaseAdmin.from('profiles').select('id,name,age,location_label,moderation_status,is_visible,last_active_at,dog').order('last_active_at',{ascending:false}).limit(40)
      if(/^[0-9a-f-]{36}$/i.test(term)) query=query.eq('id',term); else query=query.ilike('name',`%${term.replace(/[%_]/g,'')}%`)
      const {data,error}=await query
      if(error) return json({error:error.message},500)
      return json({ role, users:data??[] })
    }

    if (action === 'report_status') {
      const reportId = Number(payload?.reportId)
      const status = String(payload?.status || '')
      const note = String(payload?.note || '').slice(0,2000)
      if (!Number.isFinite(reportId) || !['pending','reviewing','resolved','dismissed'].includes(status)) return json({ error:'Invalid report update.' },400)
      const { data: report, error } = await ctx.supabaseAdmin.from('reports').update({ status, admin_note:note, reviewed_at:new Date().toISOString(), reviewed_by:userId }).eq('id',reportId).select('id,reported_user_id').single()
      if (error) return json({ error:error.message },500)
      const logAction = status === 'dismissed' ? 'dismiss' : status === 'resolved' ? 'resolve' : 'note'
      await ctx.supabaseAdmin.from('moderation_actions').insert({ admin_user_id:userId, target_user_id:report.reported_user_id, report_id:reportId, action:logAction, note })
      return json({ ok:true })
    }

    if (action === 'user_status') {
      if (role !== 'admin') return json({ error:'Admin role required for account restrictions.' },403)
      const targetUserId = String(payload?.targetUserId || '')
      const status = String(payload?.status || '')
      const note = String(payload?.note || '').slice(0,2000)
      const reportId = payload?.reportId ? Number(payload.reportId) : null
      if (!targetUserId || !['active','suspended','banned'].includes(status) || targetUserId===userId) return json({ error:'Invalid user status change.' },400)
      const { error } = await ctx.supabaseAdmin.from('profiles').update({ moderation_status:status, is_visible:status==='active', updated_at:new Date().toISOString() }).eq('id',targetUserId)
      if (error) return json({ error:error.message },500)
      const logAction = status==='active'?'restore':status==='suspended'?'suspend':'ban'
      await ctx.supabaseAdmin.from('moderation_actions').insert({ admin_user_id:userId, target_user_id:targetUserId, report_id:Number.isFinite(reportId as number)?reportId:null, action:logAction, note })
      await ctx.supabaseAdmin.from('notifications').insert({ user_id:targetUserId, kind:'safety', title:status==='active'?'Account restriction removed':'Account safety restriction', body:status==='active'?'Your Paw & Hand account is active again.':status==='suspended'?'Your Paw & Hand account has been suspended pending review.':'Your Paw & Hand account has been banned for a safety or policy violation.', data:{ moderation_status:status } })
      return json({ ok:true, status })
    }

    if (action === 'warn_user') {
      const targetUserId = String(payload?.targetUserId || '')
      const note = String(payload?.note || '').slice(0,2000)
      const reportId = payload?.reportId ? Number(payload.reportId) : null
      if (!targetUserId || targetUserId===userId || !note) return json({ error:'Target user and warning text are required.' },400)
      await ctx.supabaseAdmin.from('moderation_actions').insert({ admin_user_id:userId, target_user_id:targetUserId, report_id:Number.isFinite(reportId as number)?reportId:null, action:'warn', note })
      await ctx.supabaseAdmin.from('notifications').insert({ user_id:targetUserId, kind:'safety', title:'Safety notice from Paw & Hand', body:note.slice(0,300), data:{ report_id:Number.isFinite(reportId as number)?reportId:null } })
      return json({ ok:true })
    }

    return json({ error:'Unknown moderation action.' },400)
  }),
}
