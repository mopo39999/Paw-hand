import { withSupabase } from 'npm:@supabase/server@1.4.1'

export default {
  fetch: withSupabase({ auth: 'user' }, async (_req, ctx) => {
    const userId = ctx.userClaims?.id
    if (!userId) return Response.json({ error: 'Authenticated user not found.' }, { status: 401 })

    const { data: files, error: listError } = await ctx.supabaseAdmin.storage
      .from('profile-media')
      .list(userId, { limit: 100 })
    if (listError) return Response.json({ error: 'Could not inspect account media.' }, { status: 500 })

    const paths = (files ?? []).filter((file) => file.name).map((file) => `${userId}/${file.name}`)
    if (paths.length) {
      const { error: removeError } = await ctx.supabaseAdmin.storage.from('profile-media').remove(paths)
      if (removeError) return Response.json({ error: 'Could not remove account media.' }, { status: 500 })
    }

    const { error: deleteError } = await ctx.supabaseAdmin.auth.admin.deleteUser(userId, false)
    if (deleteError) return Response.json({ error: 'Could not delete account.' }, { status: 500 })

    return Response.json({ deleted: true })
  }),
}
