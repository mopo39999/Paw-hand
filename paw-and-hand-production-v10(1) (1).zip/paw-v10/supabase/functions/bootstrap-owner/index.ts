import { withSupabase } from 'npm:@supabase/server@1.4.1'

const OWNER_EMAIL = 'mopo39999@gmail.com'
const json = (body: unknown, status = 200) => Response.json(body, { status })

export default {
  fetch: withSupabase({ auth:'user' }, async (_req,ctx)=>{
    const userId=ctx.userClaims?.id ?? ctx.userClaims?.sub
    if(!userId) return json({error:'Authenticated user not found.'},401)
    const {data,error}=await ctx.supabaseAdmin.auth.admin.getUserById(userId)
    const user=data?.user
    if(error||!user) return json({error:'Could not verify account.'},401)
    if(String(user.email||'').toLowerCase()!==OWNER_EMAIL) return json({error:'This account is not the configured Paw & Hand owner.'},403)
    if(!user.email_confirmed_at) return json({error:'Verify the owner email before activating admin access.'},403)
    const appMetadata={...(user.app_metadata||{}),role:'admin'}
    const {error:updateError}=await ctx.supabaseAdmin.auth.admin.updateUserById(userId,{app_metadata:appMetadata})
    if(updateError) return json({error:updateError.message},500)
    return json({ok:true,role:'admin'})
  })
}
