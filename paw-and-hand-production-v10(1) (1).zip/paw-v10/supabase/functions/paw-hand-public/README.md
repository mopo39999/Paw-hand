# paw-hand-public Edge Function

Public policy/support/account-deletion entry pages for Paw & Hand.

This function is intentionally deployed with JWT verification disabled because Privacy, Terms, Safety, Support, and the account-deletion entry page must be publicly reachable. The actual deletion operation remains protected by the separate `delete-account` function, which requires a valid user JWT.

The publishable Supabase key in this source is a public client credential by design. Never place a service-role or `sb_secret_...` key here.
