import { withSupabase } from 'npm:@supabase/server@1.4.1'

const enc = new TextEncoder()
const json = (body: unknown, status = 200) => Response.json(body, { status })
const normalizePem = (value: string) => value.replace(/\\n/g,'\n').trim()
const pemBytes = (pem: string) => {
  const body = normalizePem(pem).replace(/-----BEGIN [^-]+-----/g,'').replace(/-----END [^-]+-----/g,'').replace(/\s+/g,'')
  const raw = atob(body)
  return Uint8Array.from(raw, c=>c.charCodeAt(0)).buffer
}
const b64url = (bytes: Uint8Array) => {
  let s=''; for(const b of bytes) s+=String.fromCharCode(b)
  return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
}
const b64json = (obj: unknown) => b64url(enc.encode(JSON.stringify(obj)))

async function googleAccessToken(){
  const projectId=Deno.env.get('FCM_PROJECT_ID')||''
  const email=Deno.env.get('FCM_CLIENT_EMAIL')||''
  const pem=Deno.env.get('FCM_PRIVATE_KEY')||''
  if(!projectId||!email||!pem) return null
  const now=Math.floor(Date.now()/1000)
  const unsigned=`${b64json({alg:'RS256',typ:'JWT'})}.${b64json({iss:email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600})}`
  const key=await crypto.subtle.importKey('pkcs8',pemBytes(pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign'])
  const signature=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,enc.encode(unsigned)))
  const assertion=`${unsigned}.${b64url(signature)}`
  const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})})
  const data=await response.json().catch(()=>({}))
  if(!response.ok||!data.access_token) throw new Error(data.error_description||data.error||'FCM OAuth failed')
  return {token:String(data.access_token),projectId}
}

async function apnsJwt(){
  const teamId=Deno.env.get('APNS_TEAM_ID')||''
  const keyId=Deno.env.get('APNS_KEY_ID')||''
  const pem=Deno.env.get('APNS_PRIVATE_KEY')||''
  const bundleId=Deno.env.get('APNS_BUNDLE_ID')||''
  if(!teamId||!keyId||!pem||!bundleId) return null
  const unsigned=`${b64json({alg:'ES256',kid:keyId})}.${b64json({iss:teamId,iat:Math.floor(Date.now()/1000)})}`
  const key=await crypto.subtle.importKey('pkcs8',pemBytes(pem),{name:'ECDSA',namedCurve:'P-256'},false,['sign'])
  const signature=new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,enc.encode(unsigned)))
  return {token:`${unsigned}.${b64url(signature)}`,bundleId,environment:(Deno.env.get('APNS_ENVIRONMENT')||'production').toLowerCase()}
}

const stringData=(data:Record<string,unknown>)=>Object.fromEntries(Object.entries(data||{}).map(([k,v])=>[k,typeof v==='string'?v:JSON.stringify(v)]))

async function sendAndroid(token:string,title:string,body:string,data:Record<string,unknown>){
  const auth=await googleAccessToken()
  if(!auth) return {configured:false,ok:false,status:0,error:'FCM credentials are not configured'}
  const r=await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(auth.projectId)}/messages:send`,{method:'POST',headers:{authorization:`Bearer ${auth.token}`,'content-type':'application/json'},body:JSON.stringify({message:{token,notification:{title,body},data:stringData(data),android:{priority:'high'}}})})
  const text=await r.text()
  return {configured:true,ok:r.ok,status:r.status,error:r.ok?'':text.slice(0,500)}
}

async function sendIos(token:string,title:string,body:string,data:Record<string,unknown>){
  const auth=await apnsJwt()
  if(!auth) return {configured:false,ok:false,status:0,error:'APNs credentials are not configured'}
  const host=auth.environment==='sandbox'?'https://api.sandbox.push.apple.com':'https://api.push.apple.com'
  const r=await fetch(`${host}/3/device/${encodeURIComponent(token)}`,{method:'POST',headers:{authorization:`bearer ${auth.token}`,'apns-topic':auth.bundleId,'apns-push-type':'alert','apns-priority':'10','content-type':'application/json'},body:JSON.stringify({aps:{alert:{title,body},sound:'default'},...stringData(data)})})
  const text=await r.text()
  return {configured:true,ok:r.ok,status:r.status,error:r.ok?'':text.slice(0,500)}
}

export default {
  fetch: withSupabase({ auth:'user' }, async (req,ctx)=>{
    const caller=ctx.userClaims?.id ?? ctx.userClaims?.sub
    if(!caller) return json({error:'Authenticated user not found.'},401)
    const payload=await req.json().catch(()=>({}))
    const messageId=payload?.messageId?String(payload.messageId):''
    const matchId=payload?.matchId?String(payload.matchId):''
    if(!messageId&&!matchId) return json({error:'messageId or matchId is required.'},400)

    let target=''
    let eventMatch=''
    let notificationKind='match'
    if(messageId){
      const {data:message,error}=await ctx.supabaseAdmin.from('messages').select('id,sender_id,match_id,kind').eq('id',messageId).maybeSingle()
      if(error||!message||message.sender_id!==caller) return json({error:'Message push is not authorized.'},403)
      eventMatch=message.match_id
      notificationKind=message.kind==='dog_date'?'dog_date':'message'
    }else eventMatch=matchId

    const {data:match,error:matchError}=await ctx.supabaseAdmin.from('matches').select('id,user_a,user_b').eq('id',eventMatch).maybeSingle()
    if(matchError||!match||(match.user_a!==caller&&match.user_b!==caller)) return json({error:'Match push is not authorized.'},403)
    target=match.user_a===caller?match.user_b:match.user_a

    let nQuery=ctx.supabaseAdmin.from('notifications').select('id,user_id,kind,title,body,data,push_sent_at').eq('user_id',target).is('push_sent_at',null).order('created_at',{ascending:false}).limit(1)
    nQuery=messageId?nQuery.contains('data',{message_id:messageId}):nQuery.eq('kind','match').contains('data',{match_id:eventMatch})
    const {data:rows,error:nError}=await nQuery
    if(nError) return json({error:nError.message},500)
    const notification=rows?.[0]
    if(!notification) return json({ok:true,delivered:0,alreadySent:true})
    notificationKind=notification.kind

    const {data:prefs}=await ctx.supabaseAdmin.from('notification_preferences').select('new_matches,messages,dog_dates,safety').eq('user_id',target).maybeSingle()
    const prefKey=notificationKind==='match'?'new_matches':notificationKind==='dog_date'?'dog_dates':notificationKind==='safety'?'safety':'messages'
    if(prefs&&prefs[prefKey]===false) return json({ok:true,delivered:0,skipped:'preference'})

    const {data:devices,error:deviceError}=await ctx.supabaseAdmin.from('push_devices').select('id,platform,token').eq('user_id',target).eq('enabled',true)
    if(deviceError) return json({error:deviceError.message},500)
    if(!devices?.length) return json({ok:true,delivered:0,skipped:'no_devices'})

    let delivered=0,configured=0
    for(const device of devices){
      try{
        const result=device.platform==='android'?await sendAndroid(device.token,notification.title,notification.body,{...notification.data,kind:notification.kind}):await sendIos(device.token,notification.title,notification.body,{...notification.data,kind:notification.kind})
        if(result.configured) configured++
        if(result.ok){
          delivered++
          await ctx.supabaseAdmin.from('push_devices').update({last_success_at:new Date().toISOString(),last_error:null,updated_at:new Date().toISOString()}).eq('id',device.id)
        }else{
          const disable=result.status===404||result.status===410
          await ctx.supabaseAdmin.from('push_devices').update({last_error:result.error.slice(0,500),enabled:disable?false:true,updated_at:new Date().toISOString()}).eq('id',device.id)
        }
      }catch(error){
        await ctx.supabaseAdmin.from('push_devices').update({last_error:String(error?.message||error).slice(0,500),updated_at:new Date().toISOString()}).eq('id',device.id)
      }
    }
    if(delivered>0) await ctx.supabaseAdmin.from('notifications').update({push_sent_at:new Date().toISOString()}).eq('id',notification.id).is('push_sent_at',null)
    return json({ok:true,delivered,configuredDevices:configured,totalDevices:devices.length,providerConfigurationRequired:configured===0})
  })
}
