-- Paw & Hand v9: stronger reciprocal matching, moderation state, notifications, and push device registration.

alter table public.profiles add column if not exists age_min int not null default 18;
alter table public.profiles add column if not exists age_max int not null default 99;
alter table public.profiles add column if not exists preferred_dog_sizes text[] not null default array['Small','Medium','Large','Extra large']::text[];
alter table public.profiles add column if not exists preferred_dog_energies text[] not null default array['Low','Medium','High']::text[];
alter table public.profiles add column if not exists avoid_smokers boolean not null default false;
alter table public.profiles add column if not exists require_shared_activity boolean not null default false;
alter table public.profiles add column if not exists moderation_status text not null default 'active';
alter table public.profiles add column if not exists last_active_at timestamptz not null default now();

do $$ begin
  alter table public.profiles add constraint profiles_age_range_check check (age_min between 18 and 99 and age_max between 18 and 99 and age_min <= age_max);
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_moderation_status_check check (moderation_status in ('active','suspended','banned'));
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_preferred_dog_sizes_check check (preferred_dog_sizes <@ array['Small','Medium','Large','Extra large']::text[] and cardinality(preferred_dog_sizes) > 0);
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.profiles add constraint profiles_preferred_dog_energies_check check (preferred_dog_energies <@ array['Low','Medium','High']::text[] and cardinality(preferred_dog_energies) > 0);
exception when duplicate_object then null; end $$;

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('match','message','dog_date','safety','account')),
  title text not null check (char_length(title) between 1 and 120),
  body text not null default '' check (char_length(body) <= 300),
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists notifications_user_unread_idx on public.notifications(user_id, created_at desc) where read_at is null;

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  new_matches boolean not null default true,
  messages boolean not null default true,
  dog_dates boolean not null default true,
  safety boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.push_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null check (platform in ('android','ios')),
  token text not null check (char_length(token) between 16 and 4096),
  enabled boolean not null default true,
  last_success_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, token)
);
create index if not exists push_devices_user_idx on public.push_devices(user_id) where enabled=true;

alter table public.reports add column if not exists severity text not null default 'normal';
alter table public.reports add column if not exists admin_note text not null default '';
alter table public.reports add column if not exists reviewed_at timestamptz;
alter table public.reports add column if not exists reviewed_by uuid references auth.users(id) on delete set null;
do $$ begin
  alter table public.reports add constraint reports_severity_check check (severity in ('normal','urgent','critical'));
exception when duplicate_object then null; end $$;

create table if not exists public.moderation_actions (
  id bigint generated always as identity primary key,
  admin_user_id uuid references auth.users(id) on delete set null,
  target_user_id uuid references auth.users(id) on delete set null,
  report_id bigint references public.reports(id) on delete set null,
  action text not null check (action in ('note','warn','suspend','ban','restore','dismiss','resolve')),
  note text not null default '' check (char_length(note) <= 2000),
  created_at timestamptz not null default now()
);
create index if not exists moderation_actions_target_idx on public.moderation_actions(target_user_id,created_at desc);
create index if not exists moderation_actions_report_idx on public.moderation_actions(report_id);

create or replace function private.my_match_settings()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'age', age,
    'gender', gender,
    'show_me', show_me,
    'smoking', smoking,
    'dog_size', coalesce(dog->>'size',''),
    'dog_energy', coalesce(dog->>'energy',''),
    'age_min', age_min,
    'age_max', age_max,
    'preferred_dog_sizes', to_jsonb(preferred_dog_sizes),
    'preferred_dog_energies', to_jsonb(preferred_dog_energies),
    'avoid_smokers', avoid_smokers,
    'require_shared_activity', require_shared_activity,
    'moderation_status', moderation_status
  )
  from public.profiles
  where id=(select auth.uid());
$$;

create or replace function private.my_activities()
returns text[]
language sql
stable
security definer
set search_path=public
as $$
  select activities from public.profiles where id=(select auth.uid());
$$;

revoke all on function private.my_match_settings() from public, anon;
revoke all on function private.my_activities() from public, anon;
grant execute on function private.my_match_settings(), private.my_activities() to authenticated;

create or replace function private.is_matched_with(target uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.matches m
    join public.profiles me on me.id=(select auth.uid())
    join public.profiles other_p on other_p.id=target
    where ((m.user_a=(select auth.uid()) and m.user_b=target) or (m.user_b=(select auth.uid()) and m.user_a=target))
      and me.moderation_status='active'
      and other_p.moderation_status='active'
      and not private.is_blocked_pair((select auth.uid()),target)
  );
$$;

create or replace function private.can_access_match(target_match uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.matches m
    join public.profiles a on a.id=m.user_a
    join public.profiles b on b.id=m.user_b
    where m.id=target_match
      and (m.user_a=(select auth.uid()) or m.user_b=(select auth.uid()))
      and a.moderation_status='active'
      and b.moderation_status='active'
      and not private.is_blocked_pair(m.user_a,m.user_b)
  );
$$;

create or replace function private.create_match_after_swipe()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  reciprocal boolean;
  a uuid;
  b uuid;
  both_active boolean;
begin
  if new.action not in ('like','paw_like') then return new; end if;
  select exists(
    select 1 from public.swipes
    where user_id=new.target_id and target_id=new.user_id and action in ('like','paw_like')
  ) into reciprocal;
  select count(*)=2 into both_active from public.profiles p where p.id in (new.user_id,new.target_id) and p.moderation_status='active';
  if reciprocal and both_active and not private.is_blocked_pair(new.user_id,new.target_id) then
    if new.user_id::text < new.target_id::text then a:=new.user_id; b:=new.target_id; else a:=new.target_id; b:=new.user_id; end if;
    insert into public.matches(user_a,user_b) values(a,b) on conflict do nothing;
  end if;
  return new;
end;
$$;
revoke all on function private.create_match_after_swipe() from public, anon, authenticated;

-- Reciprocal discovery: both people must satisfy one another's age/gender/smoking/dog preferences.
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (
  id=(select auth.uid())
  or private.is_matched_with(id)
  or (
    completed=true
    and is_visible=true
    and moderation_status='active'
    and id<>(select auth.uid())
    and (private.my_match_settings()->>'moderation_status')='active'
    and not private.is_blocked_pair((select auth.uid()),id)
    and not exists(select 1 from public.swipes s where s.user_id=(select auth.uid()) and s.target_id=profiles.id)
    and (
      (private.my_match_settings()->>'show_me')='Everyone'
      or ((private.my_match_settings()->>'show_me')='Women' and gender='Woman')
      or ((private.my_match_settings()->>'show_me')='Men' and gender='Man')
    )
    and (
      show_me='Everyone'
      or (show_me='Women' and (private.my_match_settings()->>'gender')='Woman')
      or (show_me='Men' and (private.my_match_settings()->>'gender')='Man')
    )
    and age between (private.my_match_settings()->>'age_min')::int and (private.my_match_settings()->>'age_max')::int
    and (private.my_match_settings()->>'age')::int between age_min and age_max
    and (not (private.my_match_settings()->>'avoid_smokers')::boolean or smoking<>'Smoker')
    and (not avoid_smokers or (private.my_match_settings()->>'smoking')<>'Smoker')
    and ((private.my_match_settings()->'preferred_dog_sizes') ? coalesce(dog->>'size',''))
    and ((private.my_match_settings()->>'dog_size') = any(preferred_dog_sizes))
    and ((private.my_match_settings()->'preferred_dog_energies') ? coalesce(dog->>'energy',''))
    and ((private.my_match_settings()->>'dog_energy') = any(preferred_dog_energies))
    and (
      (not (private.my_match_settings()->>'require_shared_activity')::boolean and not require_shared_activity)
      or activities && private.my_activities()
    )
  )
);

-- Prevent a suspended/banned user from reactivating themselves through the client.
revoke update on public.profiles from authenticated;
grant update(id,name,age,gender,show_me,looking_for,bio,kids,smoking,pace,activities,weights,dog,location_label,photo_path,dog_photo_path,completed,is_visible,updated_at,age_min,age_max,preferred_dog_sizes,preferred_dog_energies,avoid_smokers,require_shared_activity,last_active_at)
  on public.profiles to authenticated;

-- Reports are write-only from the client; moderation fields remain server/admin only.
revoke all on public.reports from authenticated;
grant insert(reporter_id,reported_user_id,reason,details,match_id,message_id) on public.reports to authenticated;
grant usage, select on sequence public.reports_id_seq to authenticated;

alter table public.notifications enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.push_devices enable row level security;
alter table public.moderation_actions enable row level security;

revoke all on public.notifications, public.notification_preferences, public.push_devices, public.moderation_actions from anon, authenticated;
grant select, update, delete on public.notifications to authenticated;
grant select, insert, update, delete on public.notification_preferences to authenticated;
grant select, insert, update, delete on public.push_devices to authenticated;

create policy notifications_read_own on public.notifications for select to authenticated using (user_id=(select auth.uid()));
create policy notifications_update_own on public.notifications for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy notifications_delete_own on public.notifications for delete to authenticated using (user_id=(select auth.uid()));

create policy notification_preferences_own on public.notification_preferences for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy push_devices_own on public.push_devices for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

create or replace function private.notify_new_match()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  name_a text;
  name_b text;
begin
  select name into name_a from public.profiles where id=new.user_a;
  select name into name_b from public.profiles where id=new.user_b;
  insert into public.notifications(user_id,kind,title,body,data) values
    (new.user_a,'match','It''s a match!',coalesce(name_b,'Someone')||' liked you too.',jsonb_build_object('match_id',new.id,'other_user_id',new.user_b)),
    (new.user_b,'match','It''s a match!',coalesce(name_a,'Someone')||' liked you too.',jsonb_build_object('match_id',new.id,'other_user_id',new.user_a));
  return new;
end;
$$;

drop trigger if exists trg_notify_new_match on public.matches;
create trigger trg_notify_new_match after insert on public.matches for each row execute function private.notify_new_match();
revoke all on function private.notify_new_match() from public, anon, authenticated;

create or replace function private.notify_new_message()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  target_user uuid;
  sender_name text;
  notification_kind text;
  notification_title text;
  notification_body text;
begin
  if new.kind='system' then return new; end if;
  select case when m.user_a=new.sender_id then m.user_b else m.user_a end into target_user
  from public.matches m where m.id=new.match_id and (m.user_a=new.sender_id or m.user_b=new.sender_id);
  if target_user is null then return new; end if;
  select name into sender_name from public.profiles where id=new.sender_id;
  notification_kind := case when new.kind='dog_date' then 'dog_date' else 'message' end;
  notification_title := case when new.kind='dog_date' then 'New Dog Date idea' else 'New message' end;
  notification_body := coalesce(sender_name,'A match') || case when new.kind='dog_date' then ' suggested a Dog Date.' else ' sent you a message.' end;
  insert into public.notifications(user_id,kind,title,body,data)
  values(target_user,notification_kind,notification_title,notification_body,jsonb_build_object('match_id',new.match_id,'message_id',new.id,'sender_id',new.sender_id));
  return new;
end;
$$;

drop trigger if exists trg_notify_new_message on public.messages;
create trigger trg_notify_new_message after insert on public.messages for each row execute function private.notify_new_message();
revoke all on function private.notify_new_message() from public, anon, authenticated;

do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;
