create or replace function private.classify_report_severity()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  new.severity := case
    when new.reason in ('Underage concern','Sexual exploitation','Threats or violence') then 'critical'
    when new.reason in ('Hate or discrimination','Unsafe behavior','Harassment') then 'urgent'
    else 'normal'
  end;
  return new;
end;
$$;
drop trigger if exists trg_report_severity_triage on public.reports;
create trigger trg_report_severity_triage before insert or update of reason on public.reports for each row execute function private.classify_report_severity();
revoke all on function private.classify_report_severity() from public, anon, authenticated;
