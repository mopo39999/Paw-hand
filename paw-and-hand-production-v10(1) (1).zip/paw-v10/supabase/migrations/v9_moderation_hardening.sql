drop policy if exists moderation_actions_deny_client on public.moderation_actions;
create policy moderation_actions_deny_client on public.moderation_actions for select to authenticated using (false);
create index if not exists moderation_actions_admin_user_idx on public.moderation_actions(admin_user_id);
create index if not exists reports_reviewed_by_idx on public.reports(reviewed_by);
revoke update on public.notifications from authenticated;
grant update(read_at) on public.notifications to authenticated;
