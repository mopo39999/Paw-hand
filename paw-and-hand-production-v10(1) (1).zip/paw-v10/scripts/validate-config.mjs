import fs from 'node:fs';

const jsonFiles=['package.json','capacitor.config.json','public/manifest.webmanifest'];
for(const file of jsonFiles){ JSON.parse(fs.readFileSync(file,'utf8')); console.log(`OK JSON ${file}`); }
const required=['index.html','privacy.html','terms.html','safety.html','support.html','delete-account.html','src/main.js','src/api.js','src/push.js','supabase/schema.sql','supabase/migrations/v9_product_layer.sql','supabase/migrations/v9_report_severity_triage.sql','supabase/migrations/v9_moderation_hardening.sql','supabase/functions/moderation-admin/index.ts','supabase/functions/paw-hand-admin/index.ts','supabase/functions/send-push/index.ts','supabase/functions/bootstrap-owner/index.ts','supabase/functions/paw-hand-public/index.ts'];
for(const file of required){ if(!fs.existsSync(file)) throw new Error(`Missing required file: ${file}`); }
console.log('Required release files present.');
