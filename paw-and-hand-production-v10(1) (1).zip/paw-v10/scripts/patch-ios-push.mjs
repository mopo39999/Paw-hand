import fs from 'node:fs';
import path from 'node:path';

const candidates = [
  'ios/App/App/AppDelegate.swift',
  'ios/App/AppDelegate.swift',
];
const file = candidates.find(fs.existsSync);
if (!file) {
  console.error('iOS AppDelegate.swift not found. Run `npx cap add ios` first.');
  process.exit(1);
}
let source = fs.readFileSync(file, 'utf8');
if (source.includes('capacitorDidRegisterForRemoteNotifications')) {
  console.log(`Push callbacks already present in ${file}`);
  process.exit(0);
}
const marker = '\n}\n';
const insert = `
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        NotificationCenter.default.post(name: .capacitorDidRegisterForRemoteNotifications, object: deviceToken)
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        NotificationCenter.default.post(name: .capacitorDidFailToRegisterForRemoteNotifications, object: error)
    }
`;
const pos = source.lastIndexOf(marker);
if (pos < 0) {
  console.error('Could not locate the AppDelegate class closing brace.');
  process.exit(1);
}
source = source.slice(0, pos) + insert + source.slice(pos);
fs.writeFileSync(file, source);
console.log(`Added Capacitor push callbacks to ${file}`);
