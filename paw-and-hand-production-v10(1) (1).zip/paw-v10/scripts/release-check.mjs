import fs from 'node:fs';

const problems=[];
const warnings=[];
const read=f=>fs.readFileSync(f,'utf8');
const env=read('.env.production');

const pkg=JSON.parse(read('package.json'));
if(pkg.version!=='10.0.0') warnings.push(`Expected v10 package, found ${pkg.version}.`);
if(!pkg.dependencies?.['@capacitor/push-notifications']) problems.push('Capacitor Push Notifications dependency is missing.');
for(const f of ['supabase/functions/moderation-admin/index.ts','supabase/functions/paw-hand-admin/index.ts','supabase/functions/send-push/index.ts','supabase/functions/bootstrap-owner/index.ts','supabase/migrations/v9_product_layer.sql']){
  if(!fs.existsSync(f)) problems.push(`Missing v9 production component: ${f}`);
}

if(!/VITE_SUPABASE_URL=https:\/\/.+\.supabase\.co/.test(env)) problems.push('Production Supabase URL is missing.');
if(!/VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_/.test(env)) warnings.push('Production env is not using a modern sb_publishable_ key.');
if(!/VITE_PUBLIC_SITE_URL=https:\/\/.+\/functions\/v1\/paw-hand-public/.test(env)) problems.push('Production public policy/support site URL is missing.');
const support=read('support.html');
if(!support.includes('mopo39999@gmail.com')) problems.push('support.html is missing the configured monitored support contact.');
const privacy=read('privacy.html');
if(!privacy.includes('mopo39999@gmail.com')) problems.push('privacy.html is missing the configured privacy contact.');
if(privacy.includes('legal operator/company name')) problems.push('Legal operator/company identity is still required before commercial release.');
const terms=read('terms.html');
if(terms.includes('should receive attorney review')) problems.push('Final attorney/legal review of Terms is still required before commercial release.');
const cap=JSON.parse(read('capacitor.config.json'));
if(cap.appId!=='com.pawandhand.app') warnings.push(`Unexpected bundle/package ID: ${cap.appId}`);
if(problems.length){
  console.error('\nRelease blockers:');
  for(const p of problems) console.error(`- ${p}`);
}
if(warnings.length){
  console.warn('\nWarnings:');
  for(const w of warnings) console.warn(`- ${w}`);
}
if(problems.length) process.exit(1);
console.log('No release-blocking placeholders detected.');
